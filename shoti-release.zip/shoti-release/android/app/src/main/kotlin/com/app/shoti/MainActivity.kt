package com.app.shoti

import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.util.Log
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper

class MainActivity: FlutterActivity() {
    // Using exact same channel name as in Dart code
    private val CHANNEL = "com.app.shoti/share"
    private var sharedText: String? = null
    private var methodChannel: MethodChannel? = null
    private lateinit var preferences: SharedPreferences
    private val PREF_NAME = "shoti_share_prefs"
    private val SHARED_TEXT_KEY = "shared_text"
    private val SHARE_TIMESTAMP_KEY = "share_timestamp"
    
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        // Initialize preferences
        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE)
        
        // Clear any stale shared texts immediately on app start
        val timestamp = preferences.getLong(SHARE_TIMESTAMP_KEY, 0)
        val currentTime = System.currentTimeMillis()
        val fiveMinutesMs = 5 * 60 * 1000
        
        // If content is older than 5 minutes, clear it
        if (currentTime - timestamp > fiveMinutesMs) {
            Log.d("Shoti", "Found stale content on app start, clearing it")
            sharedText = null
            preferences.edit()
                .remove(SHARED_TEXT_KEY)
                .remove(SHARE_TIMESTAMP_KEY)
                .apply()
        }
        
        // Create method channel with matching name
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            Log.d("Shoti", "Method ${call.method} called")
            when (call.method) {
                "getInitialSharedContent" -> {
                    Log.d("Shoti", "getInitialSharedContent called, returning: $sharedText")
                    result.success(sharedText)
                }
                "clearSharedContent" -> {
                    Log.d("Shoti", "clearSharedContent called, clearing shared text")
                    sharedText = null
                    preferences.edit()
                        .remove(SHARED_TEXT_KEY)
                        .remove(SHARE_TIMESTAMP_KEY)
                        .apply()
                    result.success(true)
                }
                else -> {
                    Log.d("Shoti", "Method not implemented: ${call.method}")
                    result.notImplemented()
                }
            }
        }
        
        // If we have fresh shared text, send it to Flutter
        if (!sharedText.isNullOrEmpty()) {
            val timestamp = preferences.getLong(SHARE_TIMESTAMP_KEY, 0)
            val currentTime = System.currentTimeMillis()
            val isFresh = (currentTime - timestamp) < 5 * 60 * 1000 // 5 minutes
            
            if (isFresh) {
                Log.d("Shoti", "Sending fresh shared text to Flutter: $sharedText")
                methodChannel?.invokeMethod("receivedShare", mapOf("text" to sharedText))
            } else {
                Log.d("Shoti", "Shared text exists but is stale, not sending")
                // Clear stale content
                sharedText = null
                preferences.edit().remove(SHARED_TEXT_KEY).apply()
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("Shoti", "MainActivity onCreate")
        handleIntent(intent)
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Log.d("Shoti", "MainActivity onNewIntent")
        setIntent(intent)
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent?) {
        if (intent == null) {
            Log.d("Shoti", "Intent is null")
            return
        }
        
        val action = intent.action
        val type = intent.type
        
        Log.d("Shoti", "Handling intent: action=$action, type=$type")
        
        if (Intent.ACTION_SEND == action && type != null) {
            if ("text/plain" == type) {
                sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                Log.d("Shoti", "Received shared text: $sharedText")
                
                // Save to preferences with timestamp
                preferences.edit()
                    .putString(SHARED_TEXT_KEY, sharedText)
                    .putLong(SHARE_TIMESTAMP_KEY, System.currentTimeMillis())
                    .apply()
                
                // Wait briefly to ensure Flutter engine is ready
                Handler(Looper.getMainLooper()).postDelayed({
                    // If Flutter engine is already initialized, send the data
                    if (methodChannel != null) {
                        Log.d("Shoti", "Sending shared content to Flutter engine")
                        methodChannel?.invokeMethod("receivedShare", mapOf("text" to sharedText))
                    } else {
                        Log.d("Shoti", "Method channel not ready, content will be sent when Flutter initializes")
                    }
                }, 500) // Short delay to ensure Flutter is ready
            }
        }
    }
}
