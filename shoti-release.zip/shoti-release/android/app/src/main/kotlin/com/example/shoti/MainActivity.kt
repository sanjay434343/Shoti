package com.example.shoti

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
