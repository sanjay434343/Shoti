plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")

}

android {
    namespace = "com.app.shoti"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = "27.0.12077973"  // Update NDK version

    compileOptions {
        // Add these lines for desugaring support
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.app.shoti"  // Update this to match Firebase config
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        // Update minSdk to 24 for camerawesome compatibility
        minSdk = 24
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName

        manifestPlaceholders["default_web_client_id"] = "571119197389-b9pub69ooaabnpd9khj3r1nhk0pl2ql8.apps.googleusercontent.com"
        manifestPlaceholders["com.google.firebase.messaging.default_notification_icon"] = "@mipmap/ic_launcher"
        manifestPlaceholders["com.google.firebase.messaging.default_notification_color"] = "#FF0000"
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build. 
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    sourceSets {
        getByName("main").java.srcDirs("src/main/kotlin")
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Add this line for desugaring
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-messaging")
}
