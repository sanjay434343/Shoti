import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shoti/firebase_options.dart';
import 'package:shoti/pages/receive_share_page.dart';
import 'package:shoti/services/auth_service.dart';
import 'package:shoti/services/share_service.dart';
import 'package:shoti/pages/splash_page.dart';
import 'package:shoti/theme/app_theme.dart';
import 'package:shoti/services/session_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shoti/services/push_notification_service.dart'; // Import PushNotificationService

// Global navigator key to access Navigator from anywhere
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// Global ShareService instance for easier access throughout the app
late ShareService shareService;
// Track when the app was started
final DateTime appStartTime = DateTime.now();

// Create a class to hold static initialization state
class AppInitializer {
  static bool isInitialized = false;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Initialize push notifications
  await PushNotificationService().init();

  await AppTheme.initialize(); // Add this line before running the app
  
  // Only initialize once using the class variable
  if (!AppInitializer.isInitialized) {
    final config = await _initializeApp();
    AppInitializer.isInitialized = true;
    
    runApp(
      Builder(
        builder: (context) {
          if (config.isShareIntent) {
            return QuickShareApp(
              sharedContent: config.initialSharedContent!,
              uid: config.loggedInUid,
            );
          }
          
          return MyApp(authService: config.authService);
        },
      ),
    );
  }
}

// Add this class to hold initialization results
class AppConfiguration {
  final bool isShareIntent;
  final String? initialSharedContent;
  final String? loggedInUid;
  final AuthService authService;

  AppConfiguration({
    required this.isShareIntent,
    this.initialSharedContent,
    this.loggedInUid,
    required this.authService,
  });
}

Future<AppConfiguration> _initializeApp() async {
  // Initialize theme colors from saved background
  final prefs = await SharedPreferences.getInstance();
  final backgroundPath = prefs.getString('background_image');
  
  // Load saved colors first
  AppTheme.loadSavedColors();
  
  if (backgroundPath != null) {
    await AppTheme.updateThemeFromImage(backgroundPath);
  }
  
  // Get session service for checking user login status
  final sessionService = await SessionService.init();
  final loggedInUid = sessionService.currentUserId;
  
  // Initialize share service first (before Firebase) to capture share intents immediately
  shareService = ShareService();
  
  try {
    await shareService.init();
    print("Share service initialized in main");
  } catch (e) {
    print("Error initializing share service: $e");
  }
  
  // Check if this is a share intent launch
  bool isShareIntent = false;
  String? initialSharedContent;
  
  try {
    initialSharedContent = shareService.lastReceivedContent;
    // Consider it a share intent if there's content
    isShareIntent = initialSharedContent != null && initialSharedContent.isNotEmpty;
    
    print("Initial share check: $initialSharedContent, isShareIntent: $isShareIntent");
  } catch (e) {
    print("Error checking for share intent: $e");
  }
  
  // Initialize Firebase regardless
  try {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: DefaultFirebaseOptions.androidApiKey,
        appId: DefaultFirebaseOptions.androidAppId,
        messagingSenderId: DefaultFirebaseOptions.androidMessagingSenderId,
        projectId: DefaultFirebaseOptions.androidProjectId,
        storageBucket: DefaultFirebaseOptions.storageBucket,
      ),
    );
    print("Firebase initialized successfully");
  } catch (e) {
    print("Error initializing Firebase: $e");
  }
  
  // Initialize Firebase Messaging
  final messaging = FirebaseMessaging.instance;
  
  // Listen for token refreshes
  messaging.onTokenRefresh.listen((token) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await FirebaseDatabase.instance
        .ref()
        .child('user_tokens')
        .child(user.uid)
        .update({
          'token': token,
          'updated': ServerValue.timestamp,
        });
    }
  });

  // Initialize auth service
  final authService = await AuthService.init();
  
  return AppConfiguration(
    isShareIntent: isShareIntent,
    initialSharedContent: initialSharedContent,
    loggedInUid: loggedInUid,
    authService: authService,
  );
}

// Add new wrapper class to handle Phoenix rebuilds
class MainAppWrapper extends StatelessWidget {
  final AuthService authService;
  
  const MainAppWrapper({
    super.key,
    required this.authService,
  });

  @override
  Widget build(BuildContext context) {
    return MyApp(authService: authService);
  }
}

// Simple app for quick share handling
class QuickShareApp extends StatelessWidget {
  final String sharedContent;
  final String? uid;
  
  const QuickShareApp({
    super.key, 
    required this.sharedContent,
    this.uid,
  });
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: ReceiveSharePage(
        sharedText: sharedContent,
        uid: uid, // Pass UID to maintain user session
      ),
    );
  }
}

class MyApp extends StatefulWidget {
  final AuthService authService;
  final String? initialSharedContent;
  
  const MyApp({
    super.key, 
    required this.authService, 
    this.initialSharedContent,
  });

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Add key to preserve state
  static final _stateKey = GlobalKey();
  
  String? _initialSharedText;
  bool _initialized = false;
  bool _firebaseInitialized = false;
  late final StreamSubscription _shareSubscription;
  late final StreamSubscription _themeSubscription;
  late SharedPreferences _prefs;
  late ThemeData _currentTheme;

  @override
  void initState() {
    super.initState();
    print("MyApp initState");
    
    _currentTheme = AppTheme.getCurrentTheme();
    
    // Listen for theme changes
    _themeSubscription = AppTheme.themeStream.listen((newTheme) {
      if (mounted) {
        setState(() => _currentTheme = newTheme);
      }
    });

    // Initialize shared preferences
    _initPrefs();
    
    // Initialize with any content passed in constructor
    _initialSharedText = widget.initialSharedContent;
    
    // Use Future.microtask to reduce work on the main thread
    Future.microtask(() {
      _checkFirebaseStatus();
      _checkForSharedIntent();
    });
    
    // Listen for new shared content
    _shareSubscription = ShareService.sharedTextStream.listen((sharedText) {
      print("Stream notification - Received shared text: $sharedText");
      if (mounted) {
        setState(() {
          _initialSharedText = sharedText;
          
          _handleNewShare(sharedText);
        });
      }
    });
  }

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
  }
  
  void _handleNewShare(String sharedText) async {
    // Get the user ID from session
    final sessionService = await SessionService.init();
    final uid = sessionService.currentUserId;
    
    // Force navigation to the receive page
    if (navigatorKey.currentState != null) {
      navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => ReceiveSharePage(
          sharedText: sharedText,
          uid: uid,
        )),
        (route) => false,
      );
    }
  }
  
  @override
  void dispose() {
    _shareSubscription.cancel();
    _themeSubscription.cancel();
    // Ensure content is cleared when app is closed
    shareService.clearSharedContent();
    super.dispose();
  }
  
  Future<void> _checkFirebaseStatus() async {
    try {
      _firebaseInitialized = Firebase.apps.isNotEmpty;
      setState(() {});
    } catch (e) {
      print("Error checking Firebase status: $e");
      _firebaseInitialized = false;
      setState(() {});
    }
  }
  
  Future<void> _checkForSharedIntent() async {
    try {
      print("Checking for shared intent...");
      final sharedText = await shareService.getInitialSharedContent();
      final isShareIntent = shareService.isShareIntent;
      
      print("Main app - Shared content check result: $sharedText (isShare: $isShareIntent)");
      
      if (mounted) {
        setState(() {
          // Fix: Handle the nullable string properly
          _initialSharedText = (sharedText != null && sharedText.isNotEmpty) ? sharedText : null;
          _initialized = true;
        });
      }
    } catch (e) {
      print("Error checking for shared intent: $e");
      if (mounted) {
        setState(() {
          _initialized = true;
        });
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    print("Building MyApp, sharedText: $_initialSharedText, initialized: $_initialized");
    
    // Always prioritize showing the receive page if we have shared content
    if (_initialSharedText != null && _initialSharedText!.isNotEmpty) {
      print("Showing receive share page with: $_initialSharedText");
      return KeyedSubtree(
        key: _stateKey,
        child: MaterialApp(
          navigatorKey: navigatorKey,
          debugShowCheckedModeBanner: false,
          title: 'Shoti App',
          theme: _currentTheme,
          home: ReceiveSharePage(sharedText: _initialSharedText),
        ),
      );
    }
    
    // Regular app flow when not handling share intent
    return KeyedSubtree(
      key: _stateKey,
      child: MaterialApp(
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        title: 'Shoti App',
        theme: _currentTheme,
        home: const SplashPage(),
        builder: (context, child) {
          // Add global error handling for Firebase initialization issues
          if (!_firebaseInitialized) {
            return MaterialApp(
              theme: AppTheme.lightTheme,
              home: Scaffold(
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, color: Colors.red, size: 48),
                      SizedBox(height: 16),
                      Text(
                        "Firebase initialization failed", 
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
                      ),
                      SizedBox(height: 8),
                      Text("Please check your internet connection and try again."),
                      SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: () async {
                          try {
                            await Firebase.initializeApp(
                              options: FirebaseOptions(
                                apiKey: DefaultFirebaseOptions.androidApiKey,
                                appId: DefaultFirebaseOptions.androidAppId,
                                messagingSenderId: DefaultFirebaseOptions.androidMessagingSenderId,
                                projectId: DefaultFirebaseOptions.androidProjectId,
                                storageBucket: DefaultFirebaseOptions.storageBucket,
                              ),
                            );
                            _firebaseInitialized = true;
                            setState(() {});
                          } catch (e) {
                            print("Retry Firebase initialization failed: $e");
                          }
                        },
                        child: Text("Retry"),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
          return child!;
        },
      ),
    );
  }
}
