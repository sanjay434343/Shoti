import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static const String androidApiKey = 'AIzaSyD9wr50rkCooYKCaPwEC-aMHYNLLvZ5Xt8';
  static const String androidAppId = '1:571119197389:android:b7ea36e3d10b0e417bdd84';
  static const String androidMessagingSenderId = '571119197389';
  static const String androidProjectId = 'shoti-d9ef8';
  static const String storageBucket = 'shoti-d9ef8.firebasestorage.app';

  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError(
        'Web platform is not supported at this time',
      );
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        throw UnsupportedError(
          'iOS platform is not supported at this time',
        );
      default:
        throw UnsupportedError(
          'Unsupported platform',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: androidApiKey,
    appId: androidAppId,
    messagingSenderId: androidMessagingSenderId,
    projectId: androidProjectId,
    storageBucket: storageBucket,
  );
}
