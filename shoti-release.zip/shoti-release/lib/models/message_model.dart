class Message {
  final String sender;
  final String content;
  final int timestamp;
  final String type;
  final bool? forwarded;
  final String? originalSender;

  Message({
    required this.sender,
    required this.content,
    required this.timestamp,
    this.type = 'text',
    Map<String, dynamic>? replyTo,
    this.forwarded,
    this.originalSender,
  });

  Map<String, dynamic> toMap() {
    return {
      'sender': sender,
      'content': content,
      'timestamp': timestamp,
      'type': type,
      'forwarded': forwarded,
      'originalSender': originalSender,
    };
  }

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      sender: map['sender'] ?? '',
      content: map['content'] ?? '',
      timestamp: map['timestamp'] ?? 0,
      type: map['type'] ?? 'text',
      forwarded: map['forwarded'],
      originalSender: map['originalSender'],
    );
  }
}

class YoutubeMessage extends Message {
  final String videoId;
  final String title;
  final bool isShort;

  YoutubeMessage({
    required super.sender,
    required super.content,
    required super.timestamp,
    required this.videoId,
    required this.title,
    this.isShort = false,
  }) : super(
          type: 'youtube',
        );

  @override
  Map<String, dynamic> toMap() {
    final baseMap = super.toMap();
    return {
      ...baseMap,
      'videoId': videoId,
      'title': title,
      'isShort': isShort,
    };
  }

  factory YoutubeMessage.fromMap(Map<String, dynamic> map) {
    return YoutubeMessage(
      sender: map['sender'] ?? '',
      content: map['content'] ?? '',
      timestamp: map['timestamp'] ?? 0,
      videoId: map['videoId'] ?? '',
      title: map['title'] ?? 'YouTube Video',
      isShort: map['isShort'] ?? false,
    );
  }
}
