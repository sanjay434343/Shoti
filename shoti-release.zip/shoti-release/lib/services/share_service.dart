import 'package:flutter/services.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shoti/services/session_service.dart';
import 'package:shoti/pages/receive_share_page.dart';
import 'package:shoti/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShareService {
  // Match exact channel name with native code
  static const platform = MethodChannel('com.app.shoti/share');
  static final StreamController<String> _sharedTextController = StreamController<String>.broadcast();

  // Stream that broadcasts new shared text
  static Stream<String> get sharedTextStream => _sharedTextController.stream;
  
  // Singleton pattern
  static final ShareService _instance = ShareService._internal();
  factory ShareService() => _instance;
  ShareService._internal();

  // For debugging - keep track of the last received content
  String? _lastReceivedContent;
  String? get lastReceivedContent => _lastReceivedContent;
  
  // Add the missing isShareIntent property
  bool _isShareIntent = false;
  bool get isShareIntent => _isShareIntent;

  // Track when shares are received
  DateTime? _shareTimestamp;
  
  // Session service for persistent storage
  late SessionService _sessionService;

  // Initialize the service and set up method call handler
  Future<void> init() async {
    try {
      _sessionService = await SessionService.init();
      platform.setMethodCallHandler(_handleMethodCall);
      print("Share service initialized successfully");
      
      // Check if there's a stored share from last session
      final storedShare = _sessionService.lastReceivedShare;
      final shareTime = _sessionService.lastShareTime;
      
      // If share is less than 10 minutes old, consider it valid
      if (storedShare != null && 
          shareTime > 0 &&
          DateTime.now().millisecondsSinceEpoch - shareTime < 10 * 60 * 1000) {
        _lastReceivedContent = storedShare;
        _shareTimestamp = DateTime.fromMillisecondsSinceEpoch(shareTime);
        _isShareIntent = true;
        _sharedTextController.add(storedShare);
      }
      
      // Make an immediate check for any shared content
      await _checkForInitialContent();
    } catch (e) {
      print("Error initializing share service: $e");
    }
  }

  // Additional method to proactively check for shared content
  Future<void> _checkForInitialContent() async {
    try {
      final content = await getInitialSharedContent();
      print("Initial check found: $content");
      if (content != null && content.isNotEmpty) {
        _lastReceivedContent = content;
        // Also save to persistent storage
        await _sessionService.saveShareInfo(content);
        _sharedTextController.add(content);
      }
    } catch (e) {
      print("Error in initial content check: $e");
    }
  }

  // Handle method calls from native platform
  Future<dynamic> _handleMethodCall(MethodCall call) async {
    print("Received method call: ${call.method}");
    switch (call.method) {
      case 'receivedShare':
        _shareTimestamp = DateTime.now();
        final Map args = call.arguments as Map;
        final String? sharedText = args['text'];
        print("Received shared text: $sharedText");
        if (sharedText != null && sharedText.isNotEmpty) {
          _lastReceivedContent = sharedText;
          _isShareIntent = true;  // Set flag when receiving share
          
          // Save to persistent storage
          await _sessionService.saveShareInfo(sharedText);
          
          // Use the global navigator key to navigate to the receive page
          final prefs = await SharedPreferences.getInstance();
          final sessionService = SessionService(prefs);
          final uid = sessionService.currentUserId;
          
          _sharedTextController.add(sharedText); // This will trigger any listeners
          
          // If we're already in a Flutter context, navigate immediately
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (navigatorKey.currentState != null) {
              print("Navigating to ReceiveSharePage with text: $sharedText");
              navigatorKey.currentState!.pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => ReceiveSharePage(
                  sharedText: sharedText,
                  uid: uid,
                )),
                (route) => false,
              );
            } else {
              print("Navigator key not available for immediate navigation");
            }
          });
        }
        return sharedText;
      default:
        throw PlatformException(
          code: 'Unimplemented',
          details: 'The method ${call.method} is not implemented',
        );
    }
  }
  
  // Get initial shared content - call this when app starts
  Future<String?> getInitialSharedContent() async {
    try {
      print("Calling getInitialSharedContent on platform channel");
      final result = await platform.invokeMethod('getInitialSharedContent');
      print("Initial shared content result: $result");
      
      if (result != null) {
        _lastReceivedContent = result.toString();
        _isShareIntent = true;  // Set flag when getting content from intent
        
        // Save to persistent storage
        await _sessionService.saveShareInfo(_lastReceivedContent!);
      }
      
      return _lastReceivedContent;
    } on PlatformException catch (e) {
      print("Failed to get initial shared content: ${e.message}");
      return null;
    } on MissingPluginException catch (e) {
      print("Missing plugin implementation: ${e.message}");
      return null;
    } catch (e) {
      print("Unexpected error getting shared content: $e");
      return null;
    }
  }

  // Clear shared content - call this when navigating away from receive page
  Future<void> clearSharedContent() async {
    try {
      // Clear locally stored content
      _lastReceivedContent = null;
      _isShareIntent = false;
      _shareTimestamp = null; // Also clear the timestamp
      
      // Clear from persistent storage too
      await _sessionService.clearShareData();
      
      // Clear on the platform side
      try {
        await platform.invokeMethod('clearSharedContent');
        print("Shared content cleared successfully");
      } catch (e) {
        // The platform might not implement this method, which is fine
        print("Note: Platform didn't handle clearSharedContent: $e");
      }
    } catch (e) {
      print("Error clearing shared content: $e");
    }
  }

  // Check if this is a fresh share or a stale one from previous launch
  bool isFreshShare(DateTime appStartTime) {
    if (_shareTimestamp == null) {
      // If we don't have a timestamp but have content from storage
      if (_lastReceivedContent != null) {
        // Get timestamp from storage
        final storedTime = _sessionService.lastShareTime;
        if (storedTime > 0) {
          final timeElapsed = DateTime.now().millisecondsSinceEpoch - storedTime;
          // Consider fresh if less than 10 minutes old
          return timeElapsed < 10 * 60 * 1000;
        }
      }
      
      return false;
    }
    
    // Otherwise, check if the share timestamp is after app start
    return _shareTimestamp!.isAfter(appStartTime);
  }
}