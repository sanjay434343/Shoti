import 'package:shared_preferences/shared_preferences.dart';

class SessionService {
  static const String _uidKey = 'uid';
  static const String _emailKey = 'email';
  static const String _lastShareTimeKey = 'last_share_time';
  static const String _lastReceivedShareKey = 'last_received_share';

  final SharedPreferences _prefs;

  SessionService(this._prefs);

  static Future<SessionService> init() async {
    final prefs = await SharedPreferences.getInstance();
    return SessionService(prefs);
  }

  Future<void> saveUserSession(String uid, String? email) async {
    await _prefs.setString(_uidKey, uid);
    if (email != null) await _prefs.setString(_emailKey, email);
  }
  
  // Store share information for persistence across app restarts
  Future<void> saveShareInfo(String content) async {
    await _prefs.setString(_lastReceivedShareKey, content);
    await _prefs.setInt(_lastShareTimeKey, DateTime.now().millisecondsSinceEpoch);
  }
  
  // Clear only share data, not user session
  Future<void> clearShareData() async {
    await _prefs.remove(_lastReceivedShareKey);
    await _prefs.remove(_lastShareTimeKey);
  }
  
  // Get stored share data
  String? get lastReceivedShare => _prefs.getString(_lastReceivedShareKey);
  int get lastShareTime => _prefs.getInt(_lastShareTimeKey) ?? 0;
  
  // Add a method to check if a share is fresh
  bool isShareFresh(int maxAgeSeconds) {
    final shareTime = lastShareTime;
    if (shareTime == 0) return false;
    
    final now = DateTime.now().millisecondsSinceEpoch;
    final age = now - shareTime;
    return age < maxAgeSeconds * 1000;
  }
  
  // Clear entire session including user data
  Future<void> clearSession() async {
    // Keep a copy of the UID before clearing
    final uid = currentUserId;
    
    await _prefs.remove(_uidKey);
    await _prefs.remove(_emailKey);
    // Always clear share data when logging out
    await clearShareData();
  }

  String? get currentUserId => _prefs.getString(_uidKey);
  String? get userEmail => _prefs.getString(_emailKey);
}
