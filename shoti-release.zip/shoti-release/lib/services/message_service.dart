import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:dart_jsonwebtoken/dart_jsonwebtoken.dart';
import 'package:firebase_database/firebase_database.dart';

class MessageService {
  static const String _projectId = 'shoti-d9ef8';
  static const String _fcmUrl = 'https://fcm.googleapis.com/v1/projects/$_projectId/messages:send';
  static const String _fcmScope = 'https://www.googleapis.com/auth/firebase.messaging';
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  // Your service account details
  static const String _serviceAccount = '''
{
  "type": "service_account",
  "project_id": "shoti-d9ef8",
  "private_key_id": "f9952d546551b5347b55f20e2606fdfca1a124a0",
  "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEuwIBADANBgkqhkiG9w0BAQEFAASCBKUwggShAgEAAoIBAQC83M9GOIfAveYV\\nCbsNgNvJBjWfyMgy4tQDFj3eq3wdRajrRSsCiDzF971udoO9BI8ICaLyZ1XOasbx\\nDzAchogugT2mDFfbwiU6gE+nu4OWE9YPY/fyXKIrRtxxgMrdw4UkGwFltRe/6ct2\\nDK3f0b1b2pFhZP88RrmD/cy6+HBb8jnajVhxwalEevACtnMNjA21aMsQXmmEG627\\nlBJ3eJGGQcI+NUYqQ4Ov2GwkLMiWId896owlasJ+pBgUqGygU92F+CXMixwQw8EL\\n/96jTTqbi8lIs2QRmnHHQqYlzrxRqQjcymz+a7aGeBSsP1eBUMMAg6IvUIl/6SBa\\nX1AatY1tAgMBAAECgf9xaux8vyDHQ4yNax/j6c3Ka0ukNXvT7rmILTrV8dB4z/Tw\\nkgDOcjMxi2rb/cofaeB7f2Zh1vXbZ+74mBQVn6jfgaVZbgP/1sJgHHE/sT3gxEXC\\n08YlXnvssiFbFJWbHgaf92cKFOFxZQgNvi4CQaN8HlJIkpVffujRhfSXkNfpCVso\\npi7uf9vKQo6Rog1wgyhHnQk58STZlDxUUq88821WpWYZ11X7g+fYI32lf96rxSHk\\nUsa5X1LNmVSzDsamNDArQheFRm+JTktXYERLOa6Hkz/QsuWNopiocDzEOxm5N8WI\\n3+7nesKCctyGR28wlnlGS3rmlNPa7um5Yxqn6xcCgYEA6F6ePHgfWwlRfUAQZ40X\\nQ9aQj35TJi/xI2iWw6+DMPgpRFTuKrOPe0h2r1iDbfyUROCONo75MyLBpVaWPDwZ\\ne6S9XdqHLetbraNfnhxydPHz1KzKH3ZfwCt14HYBNc1WBnO5j61n4hi5GMLVe4lL\\nQ1FNY/BHD5ZBSJKsoVARdqsCgYEA0BGNe+ev0VZH/kkDSmFD3JK/XRnfCOsqrOPh\\naa3Nz+CjN7iq4oHaow/3SFqGhE1RMP26Dp64XpQdOD3/twFDakJBcYbVVrETrArG\\nkbffDhHBFKrnpXrnWEWW3j5i5gXgKRTt6OeUn+oq62JNBnFiKKaY77KBYoH7F0Uo\\nC8Vo7EcCgYBUCdREnlUIwaf9GmxUZwyg9jq2CsPbrb8SRUMxZoqV7UpPcj/opaQg\\nvCZgaCywXIbrGiOUy8SIn+tU9qnDAyFcPEpYZS46h0JS3CE6t6MVdGPw6MT4+ADN\\nKWqqUUNCyA5yquvTcK1/cd2PfPdkhFT59a99k2q/0mGt844HkUOfnQKBgQCTbryY\\nPZVhegfNcSL5w234j6s1Zy2Y/jnhBCAnZ9ZcJErDIwFDOswXmyqXhD2o5bhQRJlf\\n3qu5qK4DujrGDAke9A+3R9lHcnYEBCar/mP5bi8oW+mEYlAnRjgfBonBgAxUT9Y8\\noEu5/I2o+KCnnhP1xga8Yfo4OO4YkRJNNPah5QKBgGtEHLKN0/UAizwaH/EVO/uQ\\nYDTDZaYWFC1vqMzDl30sbr4iWjm/jXbMDglSVnvXnK89rhvG5d4Ia5Khs4ZDOLZ6\\nC8TfxDiMSlCBWcc19TSrc4xN/TdJNaLdVnpsxL160r/hzMQsIPZWosVJ+zm6rFrc\\ntAMI5ohjUIk30Z6Ht3so\\n-----END PRIVATE KEY-----\\n",
  "client_email": "shoti-fcm@shoti-d9ef8.iam.gserviceaccount.com",
  "client_id": "100412703162218567668",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/shoti-fcm%40shoti-d9ef8.iam.gserviceaccount.com"
}''';

  Future<String> _getAccessToken() async {
    try {
      final serviceAccountJson = json.decode(_serviceAccount);
      final privateKey = serviceAccountJson['private_key'];
      final clientEmail = serviceAccountJson['client_email'];

      final jwt = JWT(
        {
          'iss': clientEmail,
          'scope': _fcmScope,
          'aud': 'https://oauth2.googleapis.com/token',
          'iat': (DateTime.now().millisecondsSinceEpoch / 1000).floor(),
          'exp': (DateTime.now().add(Duration(hours: 1)).millisecondsSinceEpoch / 1000).floor(),
        },
      );

      final signedJwt = jwt.sign(
        RSAPrivateKey(privateKey),
        algorithm: JWTAlgorithm.RS256,
      );

      final response = await http.post(
        Uri.parse('https://oauth2.googleapis.com/token'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer',
          'assertion': signedJwt,
        },
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return jsonData['access_token'];
      } else {
        throw Exception('Failed to get access token: ${response.body}');
      }
    } catch (e) {
      print('Error getting access token: $e');
      rethrow;
    }
  }

  String createChatId(String senderId, String receiverId) {
    final ids = [senderId, receiverId]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  Future<void> sendMessage(String senderId, String receiverId, Map<dynamic, dynamic> message) async {
    try {
      // Convert dynamic map to Map<String, Object?>
      final Map<String, Object?> sanitizedMessage = {};
      
      // Manually convert each field to ensure proper typing
      message.forEach((key, value) {
        if (key is String) {
          if (value is Map) {
            // Handle nested maps (like replyTo)
            sanitizedMessage[key] = Map<String, Object?>.from(value.map(
              (k, v) => MapEntry(k.toString(), v),
            ));
          } else {
            // Handle regular values
            sanitizedMessage[key] = value;
          }
        }
      });
      
      // Ensure required fields are present
      sanitizedMessage['sender'] = senderId;
      sanitizedMessage['timestamp'] = DateTime.now().millisecondsSinceEpoch;
      
      // Create chat ID and get message reference
      final chatId = createChatId(senderId, receiverId);
      final messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
      await _database
          .child('chats')
          .child(chatId)
          .child('messages')
          .child(messageId)
          .set(sanitizedMessage);

      // Get receiver's FCM token
      final tokenSnapshot = await _database
          .child('user_tokens')
          .child(receiverId)
          .child('token')
          .get();

      final fcmToken = tokenSnapshot.value as String?;
      if (fcmToken == null) {
        print('❌ No FCM token found for receiver: $receiverId');
        return;
      }

      // Get sender info for notification
      final senderSnapshot = await _database
          .child('public_users')
          .child(senderId)
          .get();
      final senderData = senderSnapshot.value as Map<dynamic, dynamic>?;
      final senderName = senderData?['name'] as String? ?? 'Someone';

      // Prepare FCM notification with proper typing
      final Map<String, Object?> notification = {
        'message': {
          'token': fcmToken,
          'notification': {
            'title': senderName,
            'body': sanitizedMessage['type'] == 'youtube' 
                ? '📹 Shared a ${sanitizedMessage['isShort'] == true ? 'Short' : 'Video'}'
                : sanitizedMessage['content'] ?? 'New message',
          },
          'data': {
            'chatId': chatId,
            'messageId': messageId,
            'senderId': senderId,
            'senderName': senderName,
            'type': sanitizedMessage['type'] ?? 'text',
            'content': sanitizedMessage['content'],
            'isShort': sanitizedMessage['isShort']?.toString() ?? 'false',
            'click_action': 'FLUTTER_NOTIFICATION_CLICK'
          },
          'android': {
            'notification': {
              'channel_id': 'shoti_messages',
              'notification_priority': 'PRIORITY_HIGH',
              'default_sound': true,
              'default_vibrate_timings': true,
              'visibility': 'PUBLIC',
            },
          },
        },
      };

      // Send FCM notification
      final response = await http.post(
        Uri.parse('https://fcm.googleapis.com/v1/projects/shoti-d9ef8/messages:send'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${await _getAccessToken()}',
        },
        body: json.encode(notification),
      );

      if (response.statusCode == 200) {
        print('✅ FCM notification sent successfully');
      } else {
        print('❌ Failed to send FCM notification: ${response.body}');
      }

    } catch (e) {
      print('❌ Error sending message: $e');
      rethrow;
    }
  }

  Future<void> markMessagesAsRead(String currentUserId, String otherUserId) async {
    try {
      final chatId = createChatId(currentUserId, otherUserId);
      final messagesRef = _database.child('chats').child(chatId).child('messages');
      
      final snapshot = await messagesRef.get();
      if (!snapshot.exists) return;

      final messages = snapshot.value as Map<dynamic, dynamic>;
      final Map<String, Object?> batch = {};

      messages.forEach((messageId, message) {
        if (message['sender'] != currentUserId && message['read'] != true) {
          batch['/chats/$chatId/messages/$messageId/read'] = true;
        }
      });

      if (batch.isNotEmpty) {
        await _database.update(batch);
        print('✅ Messages marked as read successfully');
      } else {
        print('ℹ️ No messages to mark as read');
      }
    } catch (e) {
      print('Error marking messages as read: $e');
    }
  }

  Future<String?> getFCMToken(String userId) async {
    try {
      final snapshot = await _database
          .child('user_tokens')
          .child(userId)
          .child('token')
          .get();
      
      return snapshot.value as String?;
    } catch (e) {
      print('Error getting FCM token: $e');
      return null;
    }
  }

  Future<void> addReaction(
    String currentUserId,
    String otherUserId,
    String messageId,
    String reaction,
  ) async {
    try {
      final chatId = createChatId(currentUserId, otherUserId);
      await _database
          .child('chats')
          .child(chatId)
          .child('messages')
          .child(messageId)
          .update({
        'reaction': reaction,
        'reactedBy': currentUserId,
        'reactionTime': ServerValue.timestamp,
      });
    } catch (e) {
      print('Error adding reaction: $e');
      rethrow;
    }
  }

  Future<void> removeReaction(
    String currentUserId,
    String otherUserId,
    String messageId,
  ) async {
    try {
      final chatId = createChatId(currentUserId, otherUserId);
      await _database
          .child('chats')
          .child(chatId)
          .child('messages')
          .child(messageId)
          .update({
        'reaction': null,
        'reactedBy': null,
        'reactionTime': null,
      });
    } catch (e) {
      print('Error removing reaction: $e');
      rethrow;
    }
  }

  Stream<List<Map<String, dynamic>>> getMessages(String currentUserId, String otherUserId) {
    final chatId = createChatId(currentUserId, otherUserId);
    
    return _database
        .child('chats')
        .child(chatId)
        .child('messages')
        .onValue
        .asBroadcastStream()
        .map((event) {
          final messagesMap = event.snapshot.value as Map<dynamic, dynamic>?;
          
          if (messagesMap == null) return [];
          
          List<Map<String, dynamic>> messages = [];
          messagesMap.forEach((key, value) {
            if (value is Map) {
              final message = Map<String, dynamic>.from(value);
              message['id'] = key;
              messages.add(message);
            }
          });
          
          messages.sort((a, b) => (a['timestamp'] ?? 0).compareTo(b['timestamp'] ?? 0));
          return messages;
        });
  }
}
