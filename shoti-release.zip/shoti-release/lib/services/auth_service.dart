import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shoti/services/session_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  final SessionService _session;

  AuthService(this._session);

  static Future<AuthService> init() async {
    final session = await SessionService.init();
    return AuthService(session);
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      // Save session
      await _session.saveUserSession(result.user!.uid, result.user?.email);

      return {
        'success': true,
        'uid': result.user?.uid,
      };
    } catch (e) {
      print('Login error: $e');
      return {'success': false, 'uid': null};
    }
  }

  Future<Map<String, dynamic>> signup(String name, String email, String password, String mobile) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      await result.user?.updateDisplayName(name);
      
      // Store private user data
      await _database.child('users').child(result.user!.uid).set({
        'name': name,
        'email': email,
        'mobile': mobile,
        'createdAt': ServerValue.timestamp,
      });

      // Store public user data
      await _database.child('public_users').child(result.user!.uid).set({
        'name': name,
        'mobile': mobile,
      });

      return {
        'success': true,
        'uid': result.user?.uid,
      };
    } catch (e) {
      print('Signup error: $e');
      return {'success': false, 'uid': null};
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    await _googleSignIn.signOut();
    await _session.clearSession();
  }

  User? get currentUser => _auth.currentUser;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<Map<String, dynamic>> checkUserData(String uid) async {
    final snapshot = await _database.child('users').child(uid).get();
    if (!snapshot.exists) {
      return {'exists': false};
    }
    final userData = snapshot.value as Map<dynamic, dynamic>;
    return {
      'exists': true,
      'hasPhone': userData['mobile'] != null,
      'hasName': userData['name'] != null,
      'data': userData
    };
  }

  Future<bool> updateUserData(String uid, Map<String, dynamic> data) async {
    try {
      // Only allow updating if it's the current user
      if (_auth.currentUser?.uid != uid) return false;

      // Update private user data
      await _database.child('users').child(uid).update(data);

      // Update public user data
      Map<String, dynamic> publicData = {
        'name': data['name'],
        'photoUrl': data['photoUrl'],
        'mobile': data['mobile'],
      };
      await _database.child('public_users').child(uid).update(publicData);

      return true;
    } catch (e) {
      print('Update user data error: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> signInWithGoogle() async {
    try {
      await _googleSignIn.signOut();
      await _auth.signOut();

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return {'success': false, 'uid': null};

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential result = await _auth.signInWithCredential(credential);
      final uid = result.user?.uid;
      if (uid == null) return {'success': false, 'uid': null};

      // Get high resolution profile photo
      String? photoUrl = result.user?.photoURL;
      if (photoUrl != null && photoUrl.contains('s96-c')) {
        // Replace Google's default size with larger size
        photoUrl = photoUrl.replaceAll('s96-c', 's400-c');
      }

      // Check if user exists in database
      final userSnapshot = await _database.child('users').child(uid).get();
      
      // Update both private and public data
      final userData = {
        'email': result.user?.email,
        'name': result.user?.displayName,
        'photoUrl': photoUrl,
        'lastLogin': ServerValue.timestamp,
        'createdAt': ServerValue.timestamp,
      };

      final publicData = {
        'name': result.user?.displayName,
        'photoUrl': photoUrl,
      };

      if (!userSnapshot.exists) {
        await _database.child('users').child(uid).set(userData);
        await _database.child('public_users').child(uid).set(publicData);
      } else {
        await _database.child('users').child(uid).update(userData);
        await _database.child('public_users').child(uid).update(publicData);
      }

      await _session.saveUserSession(uid, result.user?.email);

      return {
        'success': true,
        'uid': uid,
        'needsUpdate': false,
      };
    } catch (e) {
      print('Google sign in error: $e');
      return {'success': false, 'uid': null, 'error': e.toString()};
    }
  }

  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print('Reset password error: $e');
      rethrow;
    }
  }

  Future<Map<dynamic, dynamic>?> getUserData(String uid) async {
    try {
      final snapshot = await _database.child('users').child(uid).get();
      if (snapshot.exists) {
        return snapshot.value as Map<dynamic, dynamic>;
      }
      return null;
    } catch (e) {
      print('Get user data error: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>?> checkSession() async {
    final uid = _session.currentUserId;
    if (uid == null) return null;

    final userData = await getUserData(uid);
    if (userData == null) {
      await _session.clearSession();
      return null;
    }

    return {
      'uid': uid,
      'data': userData,
    };
  }
}
