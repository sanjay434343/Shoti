import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'contact_preferences_service.dart';

class ContactService {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  late final ContactPreferencesService _prefs;
  final List<Map<String, dynamic>> _cachedMatches = [];
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;
    
    try {
      _prefs = await ContactPreferencesService.init();
      _isInitialized = true;
      print("ContactService initialized successfully");
    } catch (e) {
      print("Error initializing ContactService: $e");
      rethrow;
    }
  }

  List<Map<String, dynamic>> get cachedMatches => _cachedMatches;

  String normalizePhoneNumber(String phone, {String countryCode = '91'}) {
    // Remove all non-digit characters and spaces
    String digits = phone.replaceAll(RegExp(r'[^\d+]'), '');
    
    // Remove any leading '+' or country codes
    if (digits.startsWith('+')) {
      digits = digits.substring(1);
    }
    if (digits.startsWith(countryCode)) {
      digits = digits.substring(countryCode.length);
    }
    
    // Get last 10 digits only
    if (digits.length >= 10) {
      digits = digits.substring(digits.length - 10);
    }
    
    return digits;
  }

  bool isPhoneMatch(String phone1, String phone2, {String countryCode = '91'}) {
    // Normalize both phone numbers
    final normalized1 = normalizePhoneNumber(phone1, countryCode: countryCode);
    final normalized2 = normalizePhoneNumber(phone2, countryCode: countryCode);
    return normalized1 == normalized2;
  }

  Future<List<Map<String, dynamic>>> getMatchingContacts({List<Contact>? contacts}) async {
    print('ContactService: Starting matching process');
    try {
      if (!_isInitialized) {
        await init();
      }

      contacts ??= await FlutterContacts.getContacts(withProperties: true);
      print('Processing ${contacts.length} device contacts');

      Map<String, Contact> contactsMap = {};
      for (final contact in contacts) {
        for (final phone in contact.phones) {
          final normalizedPhone = normalizePhoneNumber(phone.number);
          contactsMap[normalizedPhone] = contact;
        }
      }

      // Try to get cached contacts first if database access fails
      try {
        final usersSnapshot = await _database.child('public_users').get();
        if (!usersSnapshot.exists) {
          print("No users found in database, falling back to cache");
          return _prefs.getMatchedContacts();
        }

        final usersData = usersSnapshot.value as Map<dynamic, dynamic>;
        List<Map<String, dynamic>> matchingUsers = [];
        final currentUser = _auth.currentUser;

        if (currentUser == null) {
          print("No authenticated user, falling back to cache");
          return _prefs.getMatchedContacts();
        }

        await Future.forEach(usersData.entries, (entry) async {
          final uid = entry.key;
          final userData = entry.value;
          
          if (uid != currentUser.uid && userData is Map) {
            final userPhone = userData['mobile']?.toString();
            if (userPhone != null && userPhone.isNotEmpty) {
              final normalizedUserPhone = normalizePhoneNumber(userPhone);
              if (contactsMap.containsKey(normalizedUserPhone)) {
                matchingUsers.add({
                  'uid': uid,
                  'name': userData['name'] ?? 'No Name',
                  'photoUrl': userData['photoUrl'],
                  'mobile': userPhone,
                  'email': userData['email'] ?? '',
                });
              }
            }
          }
        });

        // Save successful matches to cache
        await _prefs.saveMatchedContacts(matchingUsers);
        return matchingUsers;

      } catch (dbError) {
        print("Database error: $dbError, falling back to cached contacts");
        final cachedContacts = _prefs.getMatchedContacts();
        if (cachedContacts.isNotEmpty) {
          return cachedContacts;
        }
        rethrow;
      }

    } catch (e, stackTrace) {
      print("Error in getMatchingContacts: $e");
      print("Stack trace: $stackTrace");
      return _prefs.getMatchedContacts(); // Final fallback to cache
    }
  }
}
