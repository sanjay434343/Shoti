import 'package:connectivity_plus/connectivity_plus.dart';
import 'dart:async';

class ConnectivityService {
  static final ConnectivityService _instance = ConnectivityService._internal();
  factory ConnectivityService() => _instance;
  ConnectivityService._internal();

  final _connectivity = Connectivity();
  var _controller = StreamController<bool>.broadcast();
  StreamSubscription? _subscription;
  bool _isDisposed = false;

  Stream<bool> get onConnectivityChanged => _controller.stream;

  Future<void> init() async {
    if (_isDisposed) {
      _controller = StreamController<bool>.broadcast();
      _isDisposed = false;
    }
    
    // Get initial connectivity status
    ConnectivityResult result = await _connectivity.checkConnectivity();
    _checkStatus(result);

    // Listen for changes
    _subscription?.cancel(); // Cancel any existing subscription
    _subscription = _connectivity.onConnectivityChanged.listen(_checkStatus);
  }

  void _checkStatus(ConnectivityResult result) {
    if (_isDisposed) return;
    
    bool isOnline = result != ConnectivityResult.none;
    if (!_controller.isClosed) {
      _controller.add(isOnline);
    }
  }

  Future<bool> checkConnection() async {
    final result = await _connectivity.checkConnectivity();
    return result != ConnectivityResult.none;
  }

  void dispose() {
    _subscription?.cancel();
    if (!_controller.isClosed) {
      _controller.close();
    }
    _isDisposed = true;
  }
}
