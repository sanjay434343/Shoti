import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';

class CallService {
  Future<void> makePhoneCall(String phoneNumber) async {
    // Request call permission first
    final status = await Permission.phone.request();
    if (!status.isGranted) {
      throw 'Call permission denied';
    }

    // Format phone number
    final formattedNumber = phoneNumber.replaceAll(RegExp(r'\s+'), '');
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: formattedNumber,
    );

    // Check if we can handle the call
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      throw 'Could not launch call for $formattedNumber';
    }
  }
}
