import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ContactPreferencesService {
  static const String _matchedContactsKey = 'matched_contacts';
  final SharedPreferences _prefs;

  ContactPreferencesService(this._prefs);

  static Future<ContactPreferencesService> init() async {
    final prefs = await SharedPreferences.getInstance();
    return ContactPreferencesService(prefs);
  }

  Future<void> saveMatchedContact(Map<String, dynamic> contact) async {
    final contacts = getMatchedContacts();
    if (!contacts.any((c) => c['uid'] == contact['uid'])) {
      contacts.add(contact);
      await _prefs.setString(_matchedContactsKey, jsonEncode(contacts));
    }
  }

  Future<void> saveMatchedContacts(List<Map<String, dynamic>> contacts) async {
    await _prefs.setString(_matchedContactsKey, jsonEncode(contacts));
  }

  Future<void> clearMatchedContacts() async {
    await _prefs.remove(_matchedContactsKey);
  }

  List<Map<String, dynamic>> getMatchedContacts() {
    final String? data = _prefs.getString(_matchedContactsKey);
    if (data == null) return [];
    
    List<dynamic> decoded = jsonDecode(data);
    return decoded.map((e) => Map<String, dynamic>.from(e)).toList();
  }
}
