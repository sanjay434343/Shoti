import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:convert';

class PushNotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  static final PushNotificationService _instance = PushNotificationService._internal();
  factory PushNotificationService() => _instance;
  PushNotificationService._internal();

  Future<void> init() async {
    // Request permission for notifications
    await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Initialize local notifications
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _notifications.initialize(initSettings);

    // Handle incoming messages when app is in background
    FirebaseMessaging.onBackgroundMessage(_handleBackgroundMessage);

    // Handle incoming messages when app is in foreground
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Configure notification click handling
    FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationClick);
    
    // Get initial notification if app was launched from notification
    final initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      _handleNotificationClick(initialMessage);
    }

    // Store the token when generated or refreshed
    _fcm.onTokenRefresh.listen(_updateToken);
    await _updateToken(await _fcm.getToken());
  }

  Future<void> _updateToken(String? token) async {
    if (token == null) return;
    
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await _database.child('user_tokens').child(user.uid).set({
        'token': token,
        'updated': ServerValue.timestamp,
      });
      print('🔔 FCM Token updated successfully for user: ${user.uid}');
    }
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    try {
      final data = message.data;
      final messageType = data['type'];
      final sender = data['senderName'];
      String notificationBody;

      print('');
      print('📱 ================================');
      print('📱 Received new notification:');
      print('👤 From: ${sender ?? 'Unknown'}');
      print('💬 Type: ${messageType ?? 'text'}');
      print('📝 Content: ${data['content'] ?? 'No content'}');
      print('⏰ Time: ${DateTime.now().toString()}');
      print('📱 ================================');
      print('');

      if (messageType == 'youtube') {
        notificationBody = '📹 Shared a ${data['isShort'] == 'true' ? 'Short' : 'Video'}';
        print('📱 Received YouTube share notification');
      } else {
        notificationBody = data['content'] ?? 'New message';
        print('📱 Received text message notification');
      }

      await _notifications.show(
        message.hashCode,
        sender ?? 'New Message',
        notificationBody,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'shoti_messages', 
            'Messages',
            channelDescription: 'Chat message notifications',
            importance: Importance.high,
            priority: Priority.high,
            showWhen: true,
            enableVibration: true,
            enableLights: true,
            category: AndroidNotificationCategory.message,
            fullScreenIntent: true, // Add this for more prominent display
            visibility: NotificationVisibility.public, // Show on lock screen
          ),
        ),
        payload: jsonEncode({
          'chatId': data['chatId'],
          'messageId': data['messageId'],
        }),
      );

      print('');
      print('✨ ================================');
      print('✅ Notification displayed successfully');
      print('🔔 Sound played: Yes');
      print('📳 Vibration: Yes');
      print('💡 LED: Yes');
      print('✨ ================================');
      print('');

    } catch (e, stack) {
      print('❌ Error handling notification: $e');
      print('Stack trace: $stack');
    }
  }

  void _handleNotificationClick(RemoteMessage message) {
    // TODO: Navigate to chat using:
    // message.data['chatId']
    // message.data['senderId']
    // message.data['senderName']
  }
}

// Must be a top-level function
Future<void> _handleBackgroundMessage(RemoteMessage message) async {
  print('📲 Received background message: ${message.data}');
  print('✅ Background message handled successfully');
}
