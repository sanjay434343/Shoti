import 'dart:math';

import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

class AppTheme {
  // Initialize with default colors but mark as late so they can be updated
  static late MaterialColor primaryColor;
  static late MaterialColor accentColor;
  static late Color darkTone;
  static late Color midTone;
  static late Color lightTone;

  // Theme mode control
  static bool _isDarkMode = false;
  static final StreamController<bool> _themeModeController = StreamController<bool>.broadcast();
  static final StreamController<ThemeData> _themeController = StreamController<ThemeData>.broadcast();
  static final StreamController<ThemeChangedEvent> _themeChangeController = StreamController<ThemeChangedEvent>.broadcast();

  static Stream<bool> get onThemeModeChanged => _themeModeController.stream;
  static Stream<ThemeData> get themeStream => _themeController.stream;
  static Stream<ThemeChangedEvent> get onThemeChanged => _themeChangeController.stream;

  static bool get isDarkMode => _isDarkMode;

  // Add initialization method
  static Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final darkValue = prefs.getInt('dark_tone');
    final midValue = prefs.getInt('mid_tone');
    final lightValue = prefs.getInt('light_tone');

    if (darkValue != null && midValue != null && lightValue != null) {
      // Use saved colors if available
      darkTone = Color(darkValue);
      midTone = Color(midValue);
      lightTone = Color(lightValue);
    } else {
      // Set default colors
      darkTone = Colors.blueGrey[900]!;
      midTone = Colors.blueGrey[600]!;
      lightTone = Colors.blueGrey[300]!;
    }

    // Initialize MaterialColors
    primaryColor = _createMaterialColor(_isDarkMode ? darkTone : lightTone);
    accentColor = _createMaterialColor(midTone);

    // Update themes
    _updateThemeColors();
  }

  static Future<void> setThemeMode(bool isDark) async {
    if (_isDarkMode == isDark) return;
    
    _isDarkMode = isDark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_dark_mode', isDark);
    
    // Update colors immediately
    _updateThemeColors();
    
    // Notify listeners
    _themeModeController.add(_isDarkMode);
    _themeController.add(getCurrentTheme());
  }

  static Future<void> loadThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('is_dark_mode') ?? false;
    
    // Load saved colors
    final darkValue = prefs.getInt('dark_tone');
    final midValue = prefs.getInt('mid_tone');
    final lightValue = prefs.getInt('light_tone');

    if (darkValue != null && midValue != null && lightValue != null) {
      darkTone = Color(darkValue);
      midTone = Color(midValue);
      lightTone = Color(lightValue);
      _updateThemeColors();
    }
  }

  static Future<bool> updateThemeFromImage(String imagePath) async {
    try {
      final imageFile = File(imagePath);
      final imageProvider = FileImage(imageFile);
      
      final paletteGenerator = await PaletteGenerator.fromImageProvider(
        imageProvider,
        maximumColorCount: 6,  // Reduced for faster processing
        size: Size(100, 100),  // Smaller size for faster processing
      );

      final dominantColor = paletteGenerator.dominantColor?.color ?? Colors.blueGrey;
      
      // Direct color assignments without HSL conversion
      darkTone = _adjustBrightness(dominantColor, -0.3);
      midTone = dominantColor;
      lightTone = _adjustBrightness(dominantColor, 0.3);

      await _saveColorsToPrefs(imagePath);
      _updateThemeColors();
      return true;
    } catch (e) {
      print('Error extracting colors: $e');
      return false;
    }
  }

  // Simple brightness adjustment without HSL conversion
  static Color _adjustBrightness(Color color, double factor) {
    final red = (color.red * (1 + factor)).round().clamp(0, 255);
    final green = (color.green * (1 + factor)).round().clamp(0, 255);
    final blue = (color.blue * (1 + factor)).round().clamp(0, 255);
    return Color.fromARGB(color.alpha, red, green, blue);
  }

  static Future<void> resetToDefaultColors() async {
    try {
      final defaultImagePath = 'assets/logo.png';
      final byteData = await rootBundle.load(defaultImagePath);
      final buffer = byteData.buffer;
      final tempDir = await getTemporaryDirectory();
      final tempFile = File('${tempDir.path}/default_bg.png');
      await tempFile.writeAsBytes(
        buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes)
      );

      // Save the path first
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('background_image', tempFile.path);

      // Set default colors immediately while theme generates
      darkTone = Colors.blueGrey[900]!;
      midTone = Colors.blueGrey[600]!;
      lightTone = Colors.blueGrey[300]!;

      // Update theme with default colors
      _updateThemeColors();

      // Then try to generate from image
      await updateThemeFromImage(tempFile.path);
    } catch (e) {
      print('Error setting default background: $e');
      // Colors already set to defaults above
      _updateThemeColors();
    }
  }

  static Future<void> _saveColorsToPrefs(String imagePath) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await Future.wait([
        prefs.setString('background_image', imagePath),
        prefs.setInt('dark_tone', darkTone.value),
        prefs.setInt('mid_tone', midTone.value),
        prefs.setInt('light_tone', lightTone.value),
      ]);
    } catch (e) {
      print('Error saving colors: $e');
    }
  }

  static void loadSavedColors() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final darkValue = prefs.getInt('dark_tone');
      final midValue = prefs.getInt('mid_tone');
      final lightValue = prefs.getInt('light_tone');

      if (darkValue != null && midValue != null && lightValue != null) {
        darkTone = Color(darkValue);
        midTone = Color(midValue);
        lightTone = Color(lightValue);
        primaryColor = _createMaterialColor(midTone);
        accentColor = _createMaterialColor(lightTone);
      }
    } catch (e) {
      print('Error loading saved colors: $e');
    }
  }

  static void _updateThemeColors() {
    // Create consistent material colors
    primaryColor = _createMaterialColor(_isDarkMode ? darkTone : lightTone);
    accentColor = _createMaterialColor(midTone);

    // Update themes
    lightTheme = _generateLightTheme();
    darkTheme = _generateDarkTheme();

    // Notify listeners
    _themeController.add(getCurrentTheme());
    _themeChangeController.add(ThemeChangedEvent(
      primaryColor: primaryColor,
      accentColor: accentColor,
      darkTone: darkTone,
      midTone: midTone,
      lightTone: lightTone,
    ));
  }

  static ThemeData _generateLightTheme() {
    return ThemeData(
      primaryColor: lightTone,
      colorScheme: ColorScheme.light(
        primary: lightTone,
        secondary: midTone,
        tertiary: darkTone,
      ),
      scaffoldBackgroundColor: lightTone.withOpacity(0.1),
      appBarTheme: AppBarTheme(
        elevation: 0,
        backgroundColor: lightTone,
        foregroundColor: darkTone,
        iconTheme: IconThemeData(color: darkTone),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: midTone,
          elevation: 0,
          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: darkTone,
          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          side: BorderSide(color: midTone.withOpacity(0.5)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: darkTone,
        ),
      ),
      cardTheme: CardTheme(
        elevation: 2,
        color: lightTone.withOpacity(0.7),
        shadowColor: darkTone.withOpacity(0.1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      textTheme: TextTheme(
        headlineLarge: TextStyle(fontWeight: FontWeight.bold, color: darkTone),
        headlineMedium: TextStyle(fontWeight: FontWeight.bold, color: darkTone),
        headlineSmall: TextStyle(fontWeight: FontWeight.bold, color: darkTone),
        titleLarge: TextStyle(fontWeight: FontWeight.w600, color: darkTone),
        titleMedium: TextStyle(fontWeight: FontWeight.w600, color: darkTone),
        titleSmall: TextStyle(fontWeight: FontWeight.w600, color: darkTone),
        bodyLarge: TextStyle(color: darkTone),
        bodyMedium: TextStyle(color: darkTone),
        bodySmall: TextStyle(color: darkTone.withOpacity(0.8)),
      ),
    );
  }

  static ThemeData _generateDarkTheme() {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: darkTone,
      colorScheme: ColorScheme.dark(
        primary: darkTone,
        secondary: midTone,
        tertiary: lightTone,
      ),
      scaffoldBackgroundColor: Color(0xFF121212),
      appBarTheme: AppBarTheme(
        backgroundColor: Color(0xFF1E1E1E),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: Color(0xFF242424),
        elevation: 2,
        shadowColor: Colors.black.withOpacity(0.2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: darkTone,
          elevation: 0,
          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  static MaterialColor _createMaterialColor(Color color) {
    List<double> strengths = <double>[.05, .1, .2, .3, .4, .5, .6, .7, .8, .9];
    Map<int, Color> swatch = {};
    final int r = color.red, g = color.green, b = color.blue;

    for (int i = 0; i < 10; i++) {
      final double ds = 0.5 - strengths[i];
      swatch[(strengths[i] * 1000).round()] = Color.fromRGBO(
        r + ((ds < 0 ? r : (255 - r)) * ds).round(),
        g + ((ds < 0 ? g : (255 - g)) * ds).round(),
        b + ((ds < 0 ? b : (255 - b)) * ds).round(),
        1,
      );
    }

    return MaterialColor(color.value, swatch);
  }

  static Color getTextColorForBackground(Color backgroundColor) {
    final hsl = HSLColor.fromColor(backgroundColor);
    
    // Calculate perceived brightness
    double brightness = ((backgroundColor.red * 299) +
        (backgroundColor.green * 587) +
        (backgroundColor.blue * 114)) / 1000;

    // If very light or very dark, use black or white
    if (brightness > 225) return Colors.black;
    if (brightness < 30) return Colors.white;

    // For other cases, create a contrasting color from the background
    if (hsl.lightness > 0.5) {
      // For light backgrounds, darken and saturate
      return hsl.withLightness((hsl.lightness * 0.3))
          .withSaturation(min(1, hsl.saturation * 1.5))
          .toColor();
    } else {
      // For dark backgrounds, lighten and desaturate slightly
      return hsl.withLightness(min(1, hsl.lightness * 2.5))
          .withSaturation(hsl.saturation * 0.8)
          .toColor();
    }
  }

  // App theme data
  static ThemeData lightTheme = ThemeData(
    primaryColor: lightTone,
    colorScheme: ColorScheme.light(
      primary: lightTone,
      secondary: midTone,
      tertiary: darkTone,
    ),
    scaffoldBackgroundColor: lightTone.withOpacity(0.1),
    appBarTheme: AppBarTheme(
      elevation: 0,
      backgroundColor: lightTone, // Using light tone for AppBar
      foregroundColor: darkTone, // Using dark tone for text
      iconTheme: IconThemeData(color: darkTone),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: midTone, // Using mid tone for buttons
        elevation: 0,
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: darkTone,
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        side: BorderSide(color: midTone.withOpacity(0.5)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: darkTone,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: midTone.withOpacity(0.3)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: midTone.withOpacity(0.3)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: midTone),
      ),
      filled: true,
      fillColor: lightTone.withOpacity(0.1),
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    ),
    cardTheme: CardTheme(
      elevation: 2,
      color: lightTone.withOpacity(0.7),
      shadowColor: darkTone.withOpacity(0.1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ),
    tabBarTheme: TabBarTheme(
      labelColor: darkTone,
      unselectedLabelColor: Colors.grey,
      indicator: BoxDecoration(
        border: Border(bottom: BorderSide(color: midTone, width: 2)),
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: midTone,
      foregroundColor: Colors.white,
    ),
    dividerTheme: DividerThemeData(
      space: 24,
      thickness: 1,
      color: midTone.withOpacity(0.2),
    ),
    textTheme: TextTheme(
      headlineLarge: TextStyle(
        fontWeight: FontWeight.bold,
        color: darkTone,
      ),
      headlineMedium: TextStyle(
        fontWeight: FontWeight.bold,
        color: darkTone,
      ),
      headlineSmall: TextStyle(
        fontWeight: FontWeight.bold,
        color: darkTone,
      ),
      titleLarge: TextStyle(
        fontWeight: FontWeight.w600,
        color: darkTone,
      ),
      titleMedium: TextStyle(
        fontWeight: FontWeight.w600,
        color: darkTone,
      ),
      titleSmall: TextStyle(
        fontWeight: FontWeight.w600,
        color: darkTone,
      ),
      bodyLarge: TextStyle(color: darkTone),
      bodyMedium: TextStyle(color: darkTone),
      bodySmall: TextStyle(color: darkTone.withOpacity(0.8)),
    ),
    iconTheme: IconThemeData(
      color: darkTone,
    ),
  );

  // Add dark theme
  static ThemeData darkTheme = ThemeData(
    primaryColor: darkTone,
    colorScheme: ColorScheme.dark(
      primary: darkTone,
      secondary: midTone,
      tertiary: lightTone,
    ),
    scaffoldBackgroundColor: Color(0xFF121212),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xFF1E1E1E),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    cardTheme: CardTheme(
      color: Color(0xFF242424),
      elevation: 2,
      shadowColor: Colors.black.withOpacity(0.2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Color(0xFF2A2A2A),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey[800]!),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey[800]!),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: primaryColor),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: primaryColor,
        elevation: 0,
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    ),
  );

  static ThemeData getCurrentTheme() {
    return _isDarkMode ? darkTheme : lightTheme;
  }

  // Add dispose method to properly clean up controllers
  static void dispose() {
    _themeModeController.close();
    _themeController.close();
    _themeChangeController.close();
  }
}

// Add a new class to hold theme change event data
class ThemeChangedEvent {
  final MaterialColor primaryColor;
  final MaterialColor accentColor;
  final Color darkTone;
  final Color midTone;
  final Color lightTone;

  ThemeChangedEvent({
    required this.primaryColor,
    required this.accentColor,
    required this.darkTone,
    required this.midTone,
    required this.lightTone,
  });
}
