import 'package:flutter/material.dart';
import 'package:shoti/pages/forward_page.dart';
import '../services/message_service.dart';
import '../models/message_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/youtube_player_screen.dart';
import 'package:animations/animations.dart';
import 'dart:async';
import 'package:flutter/services.dart';

class ChatPage extends StatefulWidget {
  final Map<String, dynamic> user;

  const ChatPage({super.key, required this.user});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final MessageService _messageService = MessageService();
  final _auth = FirebaseAuth.instance;
  bool _isLoading = true;

  // Stream handling
  Stream<List<Map<String, dynamic>>>? _messagesStream;
  late final StreamSubscription _messagesSubscription;
  List<Map<String, dynamic>> _currentMessages = [];

  // Other controllers and variables
  final Map<String, String> _messageReactions = {};
  final Map<String, Map<String, dynamic>> _replies = {};
  Map<String, dynamic>? _replyingTo;
  late AnimationController _inputAnimationController;
  late Animation<Offset> _slideAnimation;
  bool _showInput = false;

  // Add scroll controller
  final ScrollController _scrollController = ScrollController();

  // FCM Token
  String? _receiverFCMToken;

  @override
  void initState() {
    super.initState();

    _inputAnimationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _inputAnimationController,
      curve: Curves.easeOut,
    ));

    // Setup messages stream
    final currentUserId = _auth.currentUser!.uid;
    final otherUserId = widget.user['uid'];
    _messagesStream = _messageService.getMessages(currentUserId, otherUserId);

    // Initialize message subscription
    _messagesSubscription = _messagesStream!.listen((messages) {
      if (mounted) {
        setState(() {
          _currentMessages = messages;
          _isLoading = false;
        });
        // Scroll to bottom after frame is built
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _scrollToBottom();
        });
      }
    });

    // Mark messages as read whenever chat is opened
    _markMessagesAsRead();

    // Load receiver FCM token
    _loadReceiverFCMToken();
  }

  Future<void> _markMessagesAsRead() async {
    final currentUserId = _auth.currentUser!.uid;
    final otherUserId = widget.user['uid'];
    await _messageService.markMessagesAsRead(currentUserId, otherUserId);
  }

  Future<void> _loadReceiverFCMToken() async {
    final token = await _messageService.getFCMToken(widget.user['uid']);
    if (mounted && token != null) {
      setState(() {
        _receiverFCMToken = token;
      });
    }
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    final message = Message(
      sender: _auth.currentUser!.uid,
      content: text,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      replyTo: _replyingTo,
    );

    try {
      await _messageService.sendMessage(
        _auth.currentUser!.uid,
        widget.user['uid'],
        message.toMap(),
      );
      _messageController.clear();
      setState(() {
        _replyingTo = null;
        _showInput = false;
      });
      _inputAnimationController.reverse();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send message: $e')),
      );
    }
  }

  Future<void> _launchYouTube(String videoId, {bool isShort = false}) async {
    final url = isShort
        ? 'https://youtube.com/shorts/$videoId'
        : 'https://youtube.com/watch?v=$videoId';

    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to open YouTube')),
      );
    }
  }

  void _openVideoInApp(String videoId, String title, {bool isShort = false}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => YouTubePlayerScreen(
          videoId: videoId,
          title: title,
          isShort: isShort,
        ),
      ),
    );
  }

  void _handleReaction(String messageId, String reaction) async {
    if (messageId.isEmpty) {
      print("Error: Message ID is empty");
      return;
    }
    
    try {
      final currentUid = _auth.currentUser!.uid;
      
      final message = _currentMessages.firstWhere(
        (m) => m['id'] == messageId,
        orElse: () => throw Exception('Message not found in current chat'),
      );
      
      if (message['reaction'] == reaction && message['reactedBy'] == currentUid) {
        print("Removing existing reaction");
        await _messageService.removeReaction(
          currentUid,
          widget.user['uid'],
          messageId,
        );
      } else {
        print("Adding new reaction");
        await _messageService.addReaction(
          currentUid,
          widget.user['uid'],
          messageId,
          reaction,
        );
      }
    } catch (e) {
      print("Error handling reaction: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update reaction: $e')),
        );
      }
    }
  }

  void _handleReply(Map<String, dynamic> originalMessage) {
    setState(() {
      _replyingTo = originalMessage;
      _showInput = true;
    });
    _inputAnimationController.forward();
  }

  void _handleForward(Map<String, dynamic> message) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ForwardPage(message: message),
      ),
    );

    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Message forwarded successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Widget _buildMessageActions(Map<String, dynamic> message, bool isMine) {
    final messageId = message['id'] ?? '';
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          iconSize: 18,
          visualDensity: VisualDensity.compact,
          icon: Icon(Icons.emoji_emotions_outlined, color: Colors.grey[600]),
          onPressed: () {
            showModalBottomSheet(
              context: context,
              builder: (context) => SizedBox(
                height: 100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: ['❤️', '👍', '👎', '😂', '😮', '😢']
                      .map((e) => InkWell(
                            onTap: () {
                              _handleReaction(messageId, e);
                              Navigator.pop(context);
                            },
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: Text(e, style: TextStyle(fontSize: 24)),
                            ),
                          ))
                      .toList(),
                ),
              ),
            );
          },
        ),
        IconButton(
          iconSize: 18,
          visualDensity: VisualDensity.compact,
          icon: Icon(Icons.reply, color: Colors.grey[600]),
          onPressed: () => _handleReply(message),
        ),
        IconButton(
          iconSize: 18,
          visualDensity: VisualDensity.compact,
          icon: Icon(Icons.forward, color: Colors.grey[600]),
          onPressed: () => _handleForward(message),
        ),
        if (!isMine)
          IconButton(
            iconSize: 18,
            visualDensity: VisualDensity.compact,
            icon: Icon(Icons.more_vert, color: Colors.grey[600]),
            onPressed: () {/* TODO: Additional actions */},
          ),
      ],
    );
  }

  Widget _buildReplyPreview(Map<String, dynamic> replyTo) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8),
        border: Border(
          left: BorderSide(
            color: Theme.of(context).primaryColor,
            width: 4,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  replyTo['sender'] == _auth.currentUser!.uid ? 'You' : widget.user['name'],
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                if (replyTo['type'] == 'youtube')
                  Text(
                    '🎬 ${replyTo['title']}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  )
                else
                  Text(
                    replyTo['content'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.close, size: 16),
            onPressed: () => setState(() => _replyingTo = null),
          ),
        ],
      ),
    );
  }

  Widget _buildYoutubeMessage(Map<String, dynamic> message, bool isMine) {
    final videoId = message['videoId'];
    final reaction = message['reaction'];
    final hasReaction = reaction != null;

    // Calculate fixed dimensions
    final containerWidth = MediaQuery.of(context).size.width * 0.34;
    final containerHeight = 250.0;

    return OpenContainer(
      transitionDuration: Duration(milliseconds: 500),
      openBuilder: (context, _) => YouTubePlayerScreen(
        videoId: videoId,
        title: message['title'],
        isShort: message['isShort'] ?? false,
      ),
      closedShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      closedElevation: 0,
      closedColor: Colors.transparent,
      closedBuilder: (context, openContainer) => Container(
        margin: EdgeInsets.symmetric(vertical: 8),
        width: containerWidth,
        height: containerHeight,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            Image.network(
              'https://img.youtube.com/vi/$videoId/hqdefault.jpg',
              height: containerHeight,
              width: containerWidth,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: Colors.grey[900],
                child: Icon(Icons.error, color: Colors.white),
              ),
            ),
            if (hasReaction) // Only show reaction indicator
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    reaction,
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeMessage() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.grey[300]!,
            width: 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.youtube_searched_for,
              size: 24,
              color: Colors.red[400],
            ),
            SizedBox(height: 8),
            Text(
              'Share YouTube Shorts & Videos',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 4),
            Text(
              'Use the share button in YouTube app',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageItem(Map<String, dynamic> message, bool isMine) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (message['forwarded'] == true)
            Padding(
              padding: EdgeInsets.only(
                left: isMine ? 50 : 0,
                right: isMine ? 0 : 50,
                bottom: 4,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.forward, size: 12, color: Colors.grey[600]),
                  SizedBox(width: 4),
                  Text(
                    'Forwarded',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          if (message['replyTo'] != null)
            Padding(
              padding: EdgeInsets.only(
                left: isMine ? 50 : 0,
                right: isMine ? 0 : 50,
                bottom: 4,
              ),
              child: _buildReplyPreview(message['replyTo']),
            ),
          Container(
            margin: EdgeInsets.only(
              left: isMine ? 50 : 0,
              right: isMine ? 0 : 50,
              bottom: 0, // Remove extra margin for reaction
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Column(
                  crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    message['type'] == 'youtube'
                        ? _buildYoutubeMessage(message, isMine)
                        : Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: isMine
                                  ? Theme.of(context).primaryColor
                                  : Colors.grey[200],
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  message['content'],
                                  style: TextStyle(
                                    color: isMine ? Colors.white : Colors.black,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  _formatTimestamp(message['timestamp']),
                                  style: TextStyle(
                                    color: isMine
                                        ? Colors.white.withOpacity(0.7)
                                        : Colors.grey[600],
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                    _buildMessageActions(message, isMine),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: widget.user['photoUrl'] != null
                  ? NetworkImage(widget.user['photoUrl'])
                  : null,
              child: widget.user['photoUrl'] == null
                  ? Text(widget.user['name'][0].toUpperCase())
                  : null,
            ),
            SizedBox(width: 12),
            Text(widget.user['name']),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.bug_report),
            tooltip: 'Send Test Message',
            onPressed: () async {
              try {
                final testMessage = {
                  'sender': _auth.currentUser!.uid,
                  'content': 'This is a test message 🧪',
                  'timestamp': DateTime.now().millisecondsSinceEpoch,
                  'type': 'text',
                };

                await _messageService.sendMessage(
                  _auth.currentUser!.uid,
                  widget.user['uid'],
                  testMessage,
                );

                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Test message sent successfully! 🚀'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error sending test message: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
          ),
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('User Info'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('FCM Token:'),
                      SizedBox(height: 8),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Expanded(
                              child: Text(
                                _receiverFCMToken ?? 'Not available',
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                            if (_receiverFCMToken != null)
                              IconButton(
                                icon: Icon(Icons.copy, size: 16),
                                onPressed: () {
                                  Clipboard.setData(ClipboardData(
                                    text: _receiverFCMToken!
                                  ));
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('FCM Token copied!')),
                                  );
                                },
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  actions: [
                    TextButton(
                      child: Text('Close'),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          SafeArea(
            bottom: false,
            child: Column(
              children: [
                Expanded(
                  child: _messagesStream == null
                      ? Center(child: CircularProgressIndicator())
                      : StreamBuilder<List<Map<String, dynamic>>>(
                          stream: _messagesStream,
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting && _isLoading) {
                              return Center(child: CircularProgressIndicator());
                            }

                            if (snapshot.hasError) {
                              print('Error in messages stream: ${snapshot.error}');
                              return Center(
                                child: Text('Error loading messages'),
                              );
                            }

                            final messages = snapshot.data ?? [];

                            if (messages.isEmpty) {
                              return Center(child: _buildWelcomeMessage());
                            }

                            return ListView.builder(
                              controller: _scrollController, // Add scroll controller
                              padding: EdgeInsets.all(10),
                              reverse: false,
                              itemCount: messages.length + 1,
                              itemBuilder: (context, index) {
                                if (index == 0) {
                                  return _buildWelcomeMessage();
                                }

                                final messageIndex = index - 1;
                                final message = messages[messageIndex];
                                final isMine = message['sender'] == _auth.currentUser!.uid;

                                return _buildMessageItem(message, isMine);
                              },
                            );
                          },
                        ),
                ),
                if (_replyingTo != null)
                  Container(
                    padding: EdgeInsets.all(8),
                    color: Colors.grey[100],
                    child: _buildReplyPreview(_replyingTo!),
                  ),
                SizedBox(height: MediaQuery.of(context).padding.bottom + 16),
              ],
            ),
          ),
          if (_showInput)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SlideTransition(
                position: _slideAnimation,
                child: Container(
                  color: Colors.white,
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 
                    MediaQuery.of(context).padding.bottom + 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _messageController,
                          decoration: InputDecoration(
                            hintText: 'Reply to message...',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      IconButton(
                        icon: Icon(Icons.send),
                        onPressed: _sendMessage,
                        color: Theme.of(context).primaryColor,
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _formatTimestamp(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now = DateTime.now();

    if (date.day == now.day &&
        date.month == now.month &&
        date.year == now.year) {
      return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    }

    return '${date.day}/${date.month} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _scrollController.dispose(); // Dispose scroll controller
    _messagesSubscription.cancel();
    _messageController.dispose();
    _inputAnimationController.dispose();
    super.dispose();
  }
}
