import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
// Add this import for BackdropFilter
import 'dart:ui';
import 'user_profile_page.dart';
import '../services/auth_service.dart';
import '../services/contact_service.dart';
import '../services/call_service.dart';
import '../services/message_service.dart'; // Add this import
import '../pages/chat_page.dart';
import 'package:shoti/theme/app_theme.dart';
import 'package:shoti/services/share_service.dart';
import 'dart:async';
import 'profile_update_page.dart';  // Add this import
import 'package:firebase_auth/firebase_auth.dart'; // Add this import
import 'package:device_info_plus/device_info_plus.dart';
import 'settings_page.dart';
import 'package:animations/animations.dart';
import 'package:flutter/services.dart';
import '../services/connectivity_service.dart';
import '../widgets/network_error_widget.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_database/firebase_database.dart';

class HomePage extends StatefulWidget {
  final String? uid;
  const HomePage({super.key, this.uid});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late final AuthService _authService;
  final ContactService _contactService = ContactService();
  final CallService _callService = CallService();
  final MessageService _messageService = MessageService(); // Add this line
  final FirebaseAuth _auth = FirebaseAuth.instance; // Add this line
  late StreamSubscription _shareSubscription;
  late StreamSubscription _themeSubscription;
  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  final ConnectivityService _connectivity = ConnectivityService();
  Map<dynamic, dynamic>? userData;
  List<Map<String, dynamic>> matchingUsers = [];
  bool isLoadingUsers = false;
  bool isBackgroundLoading = false;
  bool isInitialLoad = true;
  bool _isOnline = true;

  DateTime? _lastSyncTime;
  bool _isFirstLoad = true;

  // Add variable for tracking unread counts
  final Map<String, int> _unreadCounts = {};

  String? _backgroundImagePath;

  late AnimationController _rotationController;

  // Add these properties
  bool _hasShownNotificationDialog = false;

  @override
  void initState() {
    super.initState();
    _initialize();
    _loadBackgroundImage();
    _checkPermissions();
    _setupConnectivity();
    _checkNotificationPermission();

    _rotationController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );

    // Listen for share events even in HomePage
    _shareSubscription = ShareService.sharedTextStream.listen((sharedText) {
      print("HomePage received share event: $sharedText");
      // Navigation is handled in ShareService._handleMethodCall
    });

    // Listen for theme changes
    _themeSubscription = AppTheme.onThemeChanged.listen((_) {
      if (mounted) {
        setState(() {});  // Rebuild with new theme colors
      }
    });
  }

  Future<void> _checkNotificationPermission() async {
    if (_hasShownNotificationDialog) return;

    final prefs = await SharedPreferences.getInstance();
    final hasShownDialog = prefs.getBool('has_shown_notification_dialog') ?? false;
    
    if (!hasShownDialog && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showNotificationDialog();
      });
    }
  }

  Future<void> _showNotificationDialog() async {
    if (!mounted) return;
    
    final prefs = await SharedPreferences.getInstance();
    bool hasShownDialog = prefs.getBool('has_shown_notification_dialog') ?? false;
    
    if (!hasShownDialog && mounted) {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => WillPopScope(
          onWillPop: () async => false,
          child: AlertDialog(
            title: Row(
              children: [
                Icon(Icons.notifications_active, color: AppTheme.midTone),
                SizedBox(width: 10),
                Text('Enable Notifications'),
              ],
            ),
            content: Text(
              'Would you like to receive notifications when your contacts share YouTube videos with you?'
            ),
            actions: [
              TextButton(
                onPressed: () {
                  if (mounted) {
                    SystemNavigator.pop();
                  }
                },
                child: Text('Exit App'),
              ),
              ElevatedButton(
                onPressed: () async {
                  // Request notification permission
                  final messaging = FirebaseMessaging.instance;
                  final settings = await messaging.requestPermission();
                  
                  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
                    // Get and store FCM token
                    final token = await messaging.getToken();
                    if (token != null) {
                      await _storeFCMToken(token);
                    }
                  }
                  
                  // Mark dialog as shown
                  await prefs.setBool('has_shown_notification_dialog', true);
                  _hasShownNotificationDialog = true;

                  if (mounted) {
                    Navigator.of(dialogContext).pop();
                  }
                },
                child: Text('Allow'),
              ),
            ],
          ),
        ),
      );
    }
  }

  Future<void> _storeFCMToken(String token) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await FirebaseDatabase.instance
          .ref()
          .child('user_tokens')
          .child(user.uid)
          .set({
            'token': token,
            'updated': ServerValue.timestamp,
            'platform': 'android',
            'appVersion': '1.0.0',
          });
      }
    } catch (e) {
      print('Error storing FCM token: $e');
    }
  }

  Future<void> _setupConnectivity() async {
    await _connectivity.init(); // Re-initialize the service
    if (!mounted) return;
    
    final isOnline = await _connectivity.checkConnection();
    setState(() => _isOnline = isOnline);
    
    _connectivity.onConnectivityChanged.listen((online) {
      if (mounted) {
        setState(() => _isOnline = online);
        if (!online) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('No internet connection')),
          );
        }
      }
    });
  }

  Future<void> _loadBackgroundImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('background_image');
    if (mounted && imagePath != null) {
      setState(() {
        _backgroundImagePath = imagePath;
      });
      // Ensure theme colors are updated when background changes
      await AppTheme.updateThemeFromImage(imagePath);
    }
  }

  Future<void> _checkPermissions() async {
    try {
      // Check Android version for appropriate permissions
      final androidInfo = await _deviceInfo.androidInfo;
      final sdkInt = androidInfo.version.sdkInt;

      if (sdkInt >= 33) { // Android 13 and above
        await Permission.photos.request();
        await Permission.videos.request();
      } else {
        // For Android 12 and below
        await Permission.storage.request();
      }

      // Check results and show message if needed
      if (sdkInt >= 33) {
        if (await Permission.photos.isDenied || await Permission.videos.isDenied) {
          _showPermissionDialog();
        }
      } else {
        if (await Permission.storage.isDenied) {
          _showPermissionDialog();
        }
      }
    } catch (e) {
      print('Error checking permissions: $e');
    }
  }

  void _showPermissionDialog() {
    if (mounted) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Storage Permission Required'),
          content: Text('Please grant storage access to manage profile photos and shared media.'),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.pop(context),
            ),
            TextButton(
              child: Text('Open Settings'),
              onPressed: () {
                openAppSettings();
                Navigator.pop(context);
              },
            ),
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    _rotationController.dispose();
    _shareSubscription.cancel();
    _themeSubscription.cancel();
    _connectivity.dispose();
    super.dispose();
  }

  Future<void> _initialize() async {
    // Load sync timestamp from preferences
    final prefs = await SharedPreferences.getInstance();
    final lastSync = prefs.getInt('last_contacts_sync');
    if (lastSync != null) {
      _lastSyncTime = DateTime.fromMillisecondsSinceEpoch(lastSync);
    }

    // Load cached contacts first
    await _loadCachedContacts();

    // Initialize services without loading fresh data
    await _contactService.init();
    _authService = await AuthService.init();
    await _loadUserData();

    if (mounted) {
      setState(() => isInitialLoad = false);
    }

    // Only sync contacts if this is first app launch after login
    // or if it's been more than 24 hours since last sync
    if (_isFirstLoad && (lastSync == null || DateTime.now().difference(_lastSyncTime!) > Duration(hours: 24))) {
      await _loadMatchingUsers(forceSync: true);
      _isFirstLoad = false;
    }
  }

  Future<void> _loadCachedContacts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString('cached_contacts');
      if (cached != null) {
        final List<dynamic> decoded = jsonDecode(cached);
        setState(() {
          matchingUsers = decoded.map((x) => Map<String, dynamic>.from(x)).toList();
          isLoadingUsers = false;
        });
      }
    } catch (e) {
      print('Error loading cached contacts: $e');
    }
  }

  Future<void> _loadUserData() async {
    final data = await _authService.getUserData(widget.uid!);
    if (mounted) {
      setState(() {
        userData = data;
      });

      // Check if mobile number exists
      if (data == null || (data['mobile'] ?? '').isEmpty) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ProfileUpdatePage(
              uid: widget.uid!,
              email: data?['email'],
              displayName: data?['name'],
              photoUrl: data?['photoUrl'],
            ),
          ),
        );
      }
    }
  }

  Future<void> _loadMatchingUsers({bool forceSync = false}) async {
    if (!await _connectivity.checkConnection()) {
      setState(() => isLoadingUsers = false);
      return;
    }

    if (!forceSync && _lastSyncTime != null &&
        DateTime.now().difference(_lastSyncTime!) < Duration(hours: 24)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Already synced in the last 24 hours')),
      );
      return;
    }

    setState(() {
      isLoadingUsers = true;
      isBackgroundLoading = true;
    });

    try {
      print('Starting contact sync...');

      final permission = await Permission.contacts.request();
      print('Contact permission status: ${permission.name}');

      if (!permission.isGranted) {
        throw 'Contacts permission is required to sync contacts';
      }

      print('Getting phone contacts...');
      final contacts = await FlutterContacts.getContacts(
        withProperties: true,
        withPhoto: true,
      );
      print('Found ${contacts.length} contacts on device');
      for (var contact in contacts) {
        print('Contact: ${contact.displayName} - Numbers: ${contact.phones.map((p) => p.number).join(", ")}');
      }

      print('Getting matching users...');
      final users = await _contactService.getMatchingContacts(contacts: contacts);
      print('Found ${users.length} matching users');
      for (var user in users) {
        print('Matched user: ${user['name']} - ${user['mobile']}');
      }

      if (mounted) {
        setState(() {
          matchingUsers = users;
        });
        
        // Clear existing unread counts
        _unreadCounts.clear();

        // Load unread counts for each contact
        for (var user in matchingUsers) {
          final chatId = _messageService.createChatId(_auth.currentUser!.uid, user['uid']);
          final unreadCount = await _messageService.getUnreadCount(chatId, _auth.currentUser!.uid);
          if (mounted) {
            setState(() {
              _unreadCounts[user['uid']] = unreadCount;
            });
          }
        }

        // Sort users by unread count and last message time
        matchingUsers.sort((a, b) {
          final aUnread = _unreadCounts[a['uid']] ?? 0;
          final bUnread = _unreadCounts[b['uid']] ?? 0;
          final aTime = a['lastMessageTime'] ?? 0;
          final bTime = b['lastMessageTime'] ?? 0;
          
          if (aUnread != bUnread) return bUnread.compareTo(aUnread);
          return bTime.compareTo(aTime);
        });
      }
    } catch (e) {
      print('Error in contact sync: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString()),
            action: e.toString().contains('permission')
                ? SnackBarAction(
                    label: 'Settings',
                    onPressed: openAppSettings,
                  )
                : null,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          isLoadingUsers = false;
          isBackgroundLoading = false;
        });
      }
    }
  }

  Future<void> _openSettings() async {
    // Faster animation
    _rotationController.duration = Duration(milliseconds: 800);
    _rotationController.repeat();
    
    // Quick haptic feedback
    await HapticFeedback.mediumImpact();
    Timer.periodic(Duration(milliseconds: 200), (timer) {
      if (timer.tick < 3) { // Reduced to 3 quick vibrations
        HapticFeedback.lightImpact();
      } else {
        timer.cancel();
      }
    });

    // Navigate after shorter delay
    await Future.delayed(Duration(milliseconds: 800));
    _rotationController.stop();
    
    if (!mounted) return;

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SettingsPage(
          onThemeChanged: () async {
            AppTheme.loadSavedColors();
            await _loadBackgroundImage();
            if (mounted) setState(() {});
          },
        ),
      ),
    );
  }

  Color _getTextColorForBackground(Color backgroundColor) {
    // Calculate relative luminance
    double luminance = backgroundColor.computeLuminance();
    // Use white text on dark backgrounds, black text on light backgrounds
    return luminance > 0.5 ? Colors.black : Colors.white;
  }

  Widget _buildUserCard(Map<String, dynamic> user) {
    final unreadCount = _unreadCounts[user['uid']] ?? 0;
    
    return OpenContainer(
      transitionDuration: Duration(milliseconds: 500),
      openBuilder: (context, _) => ChatPage(user: user),
      closedElevation: 0,
      closedColor: Colors.transparent,
      closedShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      closedBuilder: (context, openContainer) => Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.7), // 70% white background
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(0.8), // 70% white
                Colors.white.withOpacity(0.3), // 30% white at the gradient end
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                blurRadius: 20,
                color: Colors.black.withOpacity(0.1),
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: openContainer,
              child: Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Stack(
                      children: [
                        Hero(
                          tag: 'avatar_${user['uid']}',
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [
                                  Theme.of(context).primaryColor.withOpacity(0.8),
                                  Theme.of(context).primaryColor,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Theme.of(context).primaryColor.withOpacity(0.2),
                                  blurRadius: 8,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: user['photoUrl'] != null
                              ? ClipOval(
                                  child: Image.network(
                                    user['photoUrl'],
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(
                                      Icons.person,
                                      color: Colors.white,
                                      size: 30,
                                    ),
                                  ),
                                )
                              : Center(
                                  child: Text(
                                    (user['name'] ?? '?')[0].toUpperCase(),
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                          ),
                        ),
                        if (unreadCount > 0)
                          Positioned(
                            right: 0,
                            top: 0,
                            child: Container(
                              padding: EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.red.withOpacity(0.3),
                                    blurRadius: 4,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                unreadCount.toString(),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user['name'] ?? 'No name',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: Colors.black87,
                            ),
                          ),
                          SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(
                                Icons.phone_outlined,
                                size: 14,
                                color: Colors.grey[700],
                              ),
                              SizedBox(width: 4),
                              Text(
                                user['mobile'] ?? '',
                                style: TextStyle(
                                  color: Colors.grey[700],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Theme.of(context).primaryColor.withOpacity(0.2),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: IconButton(
                            icon: Icon(Icons.message_outlined),
                            color: Theme.of(context).primaryColor,
                            onPressed: openContainer,
                          ),
                        ),
                        SizedBox(width: 8),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.green.withOpacity(0.2),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: IconButton(
                            icon: Icon(Icons.call_outlined),
                            color: Colors.green,
                            onPressed: () async {
                              try {
                                await _callService.makePhoneCall(user['mobile']);
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(e.toString())),
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildControlsCard() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8),
      padding: EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          RotationTransition(
            turns: Tween(begin: 0.0, end: 1.0).animate(_rotationController),
            child: IconButton(
              icon: Icon(Icons.settings, size: 20),
              onPressed: _openSettings,
              color: Theme.of(context).primaryColor,
            ),
          ),
          Container(
            height: 20,
            width: 1,
            color: Colors.grey[300],
          ),
          IconButton(
            icon: Icon(Icons.refresh, size: 20),
            onPressed: isBackgroundLoading 
              ? null 
              : () async {
                  HapticFeedback.mediumImpact();
                  await _loadMatchingUsers(forceSync: true);
                },
            color: Theme.of(context).primaryColor,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    final textColor = _getTextColorForBackground(primaryColor);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: primaryColor,
        foregroundColor: textColor,
        elevation: 4,
        toolbarHeight: 70, // Increased height
        title: Text(
          'Shoti',
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        actions: [
          if (isBackgroundLoading)
            Padding(
              padding: EdgeInsets.only(right: 8),
              child: Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(textColor),
                  ),
                ),
              ),
            ),
          _buildControlsCard(), // Add the control card here
          Container(
            margin: EdgeInsets.only(right: 8, left: 8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: textColor.withOpacity(0.3),
                width: 2,
              ),
            ),
            child: IconButton(
              icon: CircleAvatar(
                radius: 16,
                backgroundColor: Colors.white24,
                backgroundImage: userData?['photoUrl'] != null 
                    ? NetworkImage(userData!['photoUrl'])
                    : null,
                child: userData?['photoUrl'] == null 
                    ? Text(
                        userData?['name']?[0].toUpperCase() ?? '?',
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.w600,
                        ),
                      )
                    : null,
              ),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => UserProfilePage(uid: widget.uid!),
                ),
              ),
            ),
          ),
        ],
      ),
      body: !_isOnline ? NetworkErrorWidget(
        onRetry: () => _loadMatchingUsers(forceSync: true),
      ) : Stack(
        children: [
          if (_backgroundImagePath != null)
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: FileImage(File(_backgroundImagePath!)),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.lightTone.withOpacity(0.3),
                    AppTheme.midTone.withOpacity(0.2),
                    AppTheme.darkTone.withOpacity(0.3),
                  ],
                ),
              ),
              child: userData == null && isInitialLoad
                ? Center(child: CircularProgressIndicator())
                : NotificationListener<ScrollNotification>(
                    onNotification: (notification) {
                      // Force a rebuild of visible items during scroll
                      if (notification is ScrollUpdateNotification) {
                        setState(() {});
                      }
                      return true;
                    },
                    child: CustomScrollView(
                      slivers: [
                        SliverPadding(
                          padding: EdgeInsets.all(8), // Reduced padding
                          sliver: SliverList(
                            delegate: SliverChildListDelegate([
                              ...matchingUsers.map((user) => _buildUserCard(user)),
                              if (matchingUsers.isEmpty && !isLoadingUsers)
                                _buildEmptyState(),
                            ]),
                          ),
                        ),
                      ],
                    ),
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.people_outline,
              size: 64,
              color: Theme.of(context).primaryColor,
            ),
          ),
          SizedBox(height: 24),
          Text(
            'No contacts found on Shoti',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Invite your friends to join!',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

extension on MessageService {
  getUnreadCount(chatId, String uid) {}
  
  createChatId(String uid, user) {}
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onPressed;

  const _ActionButton({
    required this.icon,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        icon: Icon(icon, color: color),
        onPressed: onPressed,
      ),
    );
  }
}
