import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';

class SettingsPage extends StatefulWidget {
  final Function? onThemeChanged;
  const SettingsPage({super.key, this.onThemeChanged});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String? _backgroundImagePath;
  final _imagePicker = ImagePicker();
  bool _isDarkMode = false;
  bool _isUpdating = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _backgroundImagePath = prefs.getString('background_image');
      _isDarkMode = AppTheme.isDarkMode;
    });
  }

  Future<void> _updateTheme() async {
    if (_isUpdating) return;
    try {
      setState(() => _isUpdating = true);
      
      final image = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
      );

      if (image != null && mounted) {
        await AppTheme.updateThemeFromImage(image.path);
        setState(() => _backgroundImagePath = image.path);
        widget.onThemeChanged?.call();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error updating theme: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isUpdating = false);
    }
  }

  Widget _buildCard(Widget child) {
    final isLightMode = !AppTheme.isDarkMode;
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(isLightMode ? 0.9 : 0.1),
            Colors.white.withOpacity(isLightMode ? 0.7 : 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: isLightMode 
              ? Colors.grey[200]! 
              : Colors.white.withOpacity(0.1),
        ),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isLightMode = !AppTheme.isDarkMode;
    
    return Scaffold(
      backgroundColor: isLightMode ? Colors.grey[50] : Color(0xFF121212),
      appBar: AppBar(
        title: Text('Settings'),
        elevation: 0,
      ),
      body: ListView(
        padding: EdgeInsets.symmetric(vertical: 16),
        children: [
          if (_backgroundImagePath != null)
            _buildCard(
              Container(
                height: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  image: DecorationImage(
                    image: FileImage(File(_backgroundImagePath!)),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.3),
                      ],
                    ),
                  ),
                  alignment: Alignment.bottomLeft,
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Theme Preview',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          _buildCard(
            Column(
              children: [
                ListTile(
                  leading: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.midTone.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      _isDarkMode ? Icons.dark_mode : Icons.light_mode,
                      color: AppTheme.midTone,
                    ),
                  ),
                  title: Text(
                    'Dark Mode',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: isLightMode ? Colors.black87 : Colors.white,
                    ),
                  ),
                  trailing: Switch.adaptive(
                    value: _isDarkMode,
                    onChanged: (value) async {
                      setState(() => _isDarkMode = value);
                      await AppTheme.setThemeMode(value);
                      widget.onThemeChanged?.call();
                    },
                  ),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.midTone.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.image_outlined,
                      color: AppTheme.midTone,
                    ),
                  ),
                  title: Text(
                    'Choose Theme Image',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: isLightMode ? Colors.black87 : Colors.white,
                    ),
                  ),
                  trailing: _isUpdating 
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: _updateTheme,
                ),
                Divider(height: 1),
                ListTile(
                  leading: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.midTone.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.refresh,
                      color: AppTheme.midTone,
                    ),
                  ),
                  title: Text(
                    'Reset Theme',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: isLightMode ? Colors.black87 : Colors.white,
                    ),
                  ),
                  onTap: () async {
                    await AppTheme.resetToDefaultColors();
                    widget.onThemeChanged?.call();
                    if (mounted) setState(() {});
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
