import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shoti/pages/home_page.dart';
import 'package:shoti/pages/login_page.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/share_service.dart';
import '../services/session_service.dart';
import '../services/contact_service.dart';
import '../models/message_model.dart';
import '../services/message_service.dart';
import '../widgets/youtube_player_screen.dart';
import '../theme/app_theme.dart';

class ReceiveSharePage extends StatefulWidget {
  final String? sharedText;
  final String? uid;

  const ReceiveSharePage({super.key, this.sharedText, this.uid});

  @override
  State<ReceiveSharePage> createState() => _ReceiveSharePageState();
}

class _ReceiveSharePageState extends State<ReceiveSharePage> with TickerProviderStateMixin {
  final TextEditingController _linkController = TextEditingController();
  late final StreamSubscription _shareSubscription;
  final ContactService _contactService = ContactService();
  final MessageService _messageService = MessageService();
  bool _isYouTubeLink = false;
  bool _initialized = false;
  bool _isInvalidLink = false;
  late bool _isShort;
  late String _videoId;
  late String _videoTitle;
  late SessionService _sessionService;
  String? _currentUid;
  List<Map<String, dynamic>> _contacts = [];
  final List<String> _selectedContactIds = [];
  bool _isLoadingContacts = true;
  bool _isSharing = false;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  String? _backgroundImagePath;

  @override
  void initState() {
    super.initState();
    _loadBackgroundImage();
    _initSession();
    _loadCachedContacts();

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.95,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutQuart,
    ));

    _animationController.forward();

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    _isShort = false;
    _videoId = '';
    _videoTitle = '';

    _shareSubscription = ShareService.sharedTextStream.listen((sharedText) {
      if (mounted) {
        setState(() {
          _linkController.text = sharedText;
          _analyzeLinkType();
        });
      }
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      _initializeVideoInfo();
      _initialized = true;
    }
  }

  void _initializeVideoInfo() {
    if (widget.sharedText != null) {
      _linkController.text = widget.sharedText!;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _analyzeLinkType();
      });
    }
  }

  Future<void> _loadBackgroundImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('background_image');
    if (mounted && imagePath != null) {
      setState(() {
        _backgroundImagePath = imagePath;
      });
    }
  }

  Future<void> _initSession() async {
    _sessionService = await SessionService.init();

    setState(() {
      _currentUid = widget.uid ?? _sessionService.currentUserId;
    });

    print("ReceiveSharePage initialized with UID: $_currentUid");

    _loadContacts();
  }

  Future<void> _loadCachedContacts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString('cached_contacts');
      if (cached != null) {
        final List<dynamic> decoded = jsonDecode(cached);
        setState(() {
          _contacts = decoded.map((x) => Map<String, dynamic>.from(x)).toList();
          _isLoadingContacts = false;
        });
      }
    } catch (e) {
      print('Error loading cached contacts: $e');
    }
  }

  Future<void> _loadContacts() async {
    print("Starting to load contacts");
    setState(() {
      _isLoadingContacts = true;
    });

    try {
      await _contactService.init();
      final contacts = await _contactService.getMatchingContacts();

      print("Contacts loaded: ${contacts.length}");

      if (mounted) {
        setState(() {
          _contacts = contacts;
          _isLoadingContacts = false;
        });
      }
    } catch (e) {
      print("Error loading contacts: $e");
      if (mounted) {
        setState(() {
          _isLoadingContacts = false;
        });
      }
    }
  }

  void _toggleContactSelection(String uid) {
    setState(() {
      if (_selectedContactIds.contains(uid)) {
        _selectedContactIds.remove(uid);
      } else {
        _selectedContactIds.add(uid);
      }
    });
  }

  void _analyzeLinkType() {
    final text = _linkController.text;

    if (text.toLowerCase().contains('youtube.com/') || text.toLowerCase().contains('youtu.be/')) {
      setState(() {
        _isYouTubeLink = true;
        _isInvalidLink = false;

        _isShort = text.toLowerCase().contains('/shorts/');

        RegExp regExp;
        if (text.toLowerCase().contains('youtu.be/')) {
          regExp = RegExp(r'youtu\.be/([^?&]+)', caseSensitive: false);
        } else if (text.toLowerCase().contains('/shorts/')) {
          regExp = RegExp(r'/shorts/([^?&]+)', caseSensitive: false);
        } else {
          regExp = RegExp(r'youtube\.com/watch\?v=([^?&]+)', caseSensitive: false);
        }

        final match = regExp.firstMatch(text);
        if (match != null) {
          _videoId = match.group(1) ?? "";
        }

        if (text.contains('- YouTube') || text.contains('- youtube')) {
          var parts = text.split('- YouTube');
          if (parts.isEmpty || parts.length == 1) {
            parts = text.split('- youtube');
          }
          if (parts.isNotEmpty) {
            _videoTitle = parts[0].trim();
          }
        }
      });
    } else {
      setState(() {
        _isYouTubeLink = false;
        _videoId = "";
        _videoTitle = "";
        _isShort = false;
        _isInvalidLink = true;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Only YouTube links are supported'),
            duration: Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
          ),
        );
        Future.delayed(Duration(seconds: 2), () {
          if (mounted) _goToHome();
        });
      }
    }
  }

  void _openVideoInApp(String videoId, String title, {bool isShort = false}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => YouTubePlayerScreen(
          videoId: videoId,
          title: title,
          isShort: isShort,
        ),
      ),
    );
  }

  void _shareWithSelectedContacts() async {
    if (_selectedContactIds.isEmpty) return;
    setState(() => _isSharing = true);

    try {
      final message = YoutubeMessage(
        sender: _currentUid!,
        content: _linkController.text,
        timestamp: DateTime.now().millisecondsSinceEpoch,
        title: _videoTitle.isEmpty ? 'YouTube Video' : _videoTitle,
        videoId: _videoId,
        isShort: _isShort,
      );

      await Future.wait(_selectedContactIds.map((contactId) async {
        try {
          await _messageService.sendMessage(
            _currentUid!, 
            contactId,
            message.toMap()
          );
        } catch (e) {
          print('Error sending to $contactId: $e');
        }
      }));

      if (Navigator.canPop(context)) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => HomePage(uid: _currentUid!)),
          (route) => false,
        );
      } else {
        SystemNavigator.pop();
      }
      
    } catch (e) {
      print('Error in sharing process: $e');
      setState(() => _isSharing = false);
    }
  }

  void _goToHome() {
    _clearSharedContentAndNavigate();
  }

  void _clearSharedContentAndNavigate() async {
    await ShareService().clearSharedContent();

    if (!mounted) return;

    if (_currentUid != null) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => HomePage(uid: _currentUid!)),
        (route) => false,
      );
    } else {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
        (route) => false,
      );
    }
  }

  Widget _buildVideoCard() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _openVideoInApp(_videoId, _videoTitle, isShort: _isShort),
          borderRadius: BorderRadius.circular(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left side - Video thumbnail
              SizedBox(
                width: 110,
                height: 180,
                child: ClipRRect(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(12),
                    bottomLeft: Radius.circular(12),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        'https://img.youtube.com/vi/$_videoId/hqdefault.jpg',
                        fit: BoxFit.cover,
                      ),
                      // Play icon overlay
                      Center(
                        child: Container(
                          padding: EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.play_arrow,
                            color: Colors.white,
                            size: 36,
                          ),
                        ),
                      ),
                      // Video type badge
                    
                    ],
                  ),
                ),
              ),
              // Right side - Video details
              Expanded(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _videoTitle.isEmpty ? 'YouTube Video' : _videoTitle,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.darkTone,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            _isShort ? Icons.motion_photos_auto : Icons.ondemand_video,
                            size: 16,
                            color: Colors.grey[600],
                          ),
                          SizedBox(width: 4),
                          Text(
                            _isShort ? 'YouTube Short' : 'YouTube Video',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Colors.grey[300]!,
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                _linkController.text,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[800],
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.copy),
                              iconSize: 18,
                              visualDensity: VisualDensity.compact,
                              onPressed: () async {
                                await Clipboard.setData(
                                  ClipboardData(text: _linkController.text),
                                );
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Link copied!')),
                                  );
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final backgroundColor = Theme.of(context).primaryColor;
    final textColor = AppTheme.getTextColorForBackground(backgroundColor);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: true,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 4,
        title: Text(
          'Share with Shotis',
          style: TextStyle(
            color: backgroundColor.computeLuminance() < 0.5 
              ? Colors.white
              : Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: IconThemeData(color: textColor),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadContacts,
            color: textColor,
          ),
          IconButton(
            icon: Icon(Icons.home),
            onPressed: _goToHome,
            color: textColor,
          ),
        ],
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: _goToHome,
        ),
      ),
      body: _isInvalidLink 
        ? Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error_outline, size: 64, color: Colors.red),
                SizedBox(height: 16),
                Text(
                  'Link Not Supported',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text('Only YouTube links are supported'),
              ],
            ),
          )
        : Container(
            decoration: _backgroundImagePath != null
                ? BoxDecoration(
                    image: DecorationImage(
                      image: FileImage(File(_backgroundImagePath!)),
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    ),
                  )
                : BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                  ),
            child: SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: CustomScrollView(
                      physics: BouncingScrollPhysics(),
                      slivers: [
                        if (!_isYouTubeLink && _linkController.text.isNotEmpty)
                          SliverFillRemaining(
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.error_outline,
                                    size: 64,
                                    color: Colors.red,
                                  ),
                                  SizedBox(height: 16),
                                  Text(
                                    'Link Not Supported',
                                    style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Only YouTube links are supported',
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white.withOpacity(0.7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        else
                          SliverToBoxAdapter(
                            child: _isYouTubeLink ? _buildVideoCard() : SizedBox(),
                          ),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Text(
                              'Choose Shotis',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.3),
                                    offset: Offset(0, 2),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        if (_isLoadingContacts)
                          SliverFillRemaining(
                            child: Center(child: CircularProgressIndicator()),
                          )
                        else if (_contacts.isEmpty)
                          SliverFillRemaining(
                            child: Center(
                              child: Text(
                                'No contacts found',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          )
                        else
                          SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                final contact = _contacts[index];
                                final contactUid = contact['uid'] as String? ?? '';
                                final isSelected = _selectedContactIds.contains(contactUid);

                                return Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.7),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isSelected 
                                          ? Theme.of(context).primaryColor 
                                          : Colors.grey.withOpacity(0.2),
                                        width: isSelected ? 2 : 1,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          blurRadius: 20,
                                          color: Colors.black.withOpacity(0.1),
                                          offset: Offset(0, 4),
                                        ),
                                      ],
                                    ),
                                    child: ListTile(
                                      onTap: () => _toggleContactSelection(contactUid),
                                      contentPadding: EdgeInsets.all(12),
                                      leading: Hero(
                                        tag: 'contact_${contact['uid']}',
                                        child: CircleAvatar(
                                          radius: 25,
                                          backgroundColor: Theme.of(context).primaryColor.withOpacity(0.8),
                                          backgroundImage: contact['photoUrl'] != null
                                              ? NetworkImage(contact['photoUrl'])
                                              : null,
                                          child: contact['photoUrl'] == null
                                              ? Text(
                                                  (contact['name'] ?? '?')[0].toUpperCase(),
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                )
                                              : null,
                                        ),
                                      ),
                                      title: Text(
                                        contact['name'] ?? 'No name',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: AppTheme.darkTone,
                                        ),
                                      ),
                                      subtitle: Text(
                                        contact['mobile'] ?? '',
                                        style: TextStyle(
                                          color: AppTheme.darkTone.withOpacity(0.7),
                                        ),
                                      ),
                                      trailing: Container(
                                        width: 32,
                                        height: 32,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: isSelected
                                              ? Theme.of(context).primaryColor
                                              : Colors.white.withOpacity(0.3),
                                          border: Border.all(
                                            color: isSelected
                                                ? Theme.of(context).primaryColor
                                                : Colors.grey.withOpacity(0.2),
                                            width: 2,
                                          ),
                                        ),
                                        child: Icon(
                                          isSelected ? Icons.check : Icons.add,
                                          size: 16,
                                          color: isSelected ? Colors.white : AppTheme.darkTone,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                              childCount: _contacts.length,
                            ),
                          ),
                        SliverToBoxAdapter(
                          child: SizedBox(height: 100),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      floatingActionButton: _selectedContactIds.isNotEmpty && _isYouTubeLink
          ? Container(
              margin: EdgeInsets.only(bottom: 16),
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: FloatingActionButton.extended(
                  onPressed: _isSharing ? null : _shareWithSelectedContacts,
                  heroTag: 'share_with_contacts',
                  backgroundColor: Theme.of(context).primaryColor,
                  elevation: 4,
                  label: _isSharing
                      ? SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : Row(
                          children: [
                            Text(
                              'Share with ${_selectedContactIds.length}',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(width: 8),
                            Icon(Icons.send, size: 18),
                          ],
                        ),
                ),
              ),
            )
          : null,
    );
  }

  @override
  void dispose() {
    ShareService().clearSharedContent();
    _linkController.dispose();
    _shareSubscription.cancel();
    _animationController.dispose();

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);
    super.dispose();
  }
}
