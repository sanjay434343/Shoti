import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shoti/services/auth_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'login_page.dart';
import 'home_page.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  bool _initError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    // Check Firebase initialization status first
    if (Firebase.apps.isEmpty) {
      setState(() {
        _initError = true;
        _errorMessage = "Firebase not initialized. Please restart the app.";
      });
      return;
    }

    try {
      await _requestContactPermission();
      
      // Initialize auth service
      final authService = await AuthService.init();
      
      // Check for existing session
      final session = await authService.checkSession();
      
      await Future.delayed(const Duration(milliseconds: 1600)); // Doubled from 800
      if (!mounted) return;

      if (session != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage(uid: session['uid'])),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _initError = true;
          _errorMessage = "Error initializing app: ${e.toString()}";
        });
      }
    }
  }

  Future<void> _requestContactPermission() async {
    final status = await Permission.contacts.request();
    if (status.isGranted) {
      // Permission granted, you can read contacts here
      print('Contact permission granted');
    } else if (status.isDenied) {
      print('Contact permission denied');
    } else if (status.isPermanentlyDenied) {
      // Open app settings if permission is permanently denied
      await openAppSettings();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: _initError 
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, color: Colors.red, size: 64),
                  SizedBox(height: 24),
                  Text(
                    'Initialization Error',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32.0),
                    child: Text(
                      _errorMessage,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                  ),
                  SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _initializeApp,
                    child: Text('Retry'),
                  ),
                ],
              )
            : Hero(  // Add Hero widget for animation
                tag: 'app_logo',
                child: TweenAnimationBuilder(
                  duration: const Duration(milliseconds: 1600), // Doubled from 800
                  curve: Curves.easeInOut, // Added smooth curve
                  tween: Tween<double>(begin: 0, end: 1),
                  builder: (context, double value, child) {
                    return Transform.scale(
                      scale: value,
                      child: child,
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Image.asset(
                      'assets/logo.png',
                      width: 150,
                      height: 150,
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}
