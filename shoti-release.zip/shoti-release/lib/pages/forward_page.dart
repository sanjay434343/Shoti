import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/message_service.dart';
import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';

class ForwardPage extends StatefulWidget {
  final Map<String, dynamic> message;

  const ForwardPage({super.key, required this.message});

  @override
  State<ForwardPage> createState() => _ForwardPageState();
}

class _ForwardPageState extends State<ForwardPage> {
  List<Map<String, dynamic>> _contacts = [];
  final List<String> _selectedContactIds = [];
  bool _isLoading = true;
  bool _isForwarding = false;
  final MessageService _messageService = MessageService();
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _loadCachedContacts();
  }

  Future<void> _loadCachedContacts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString('cached_contacts');
      if (cached != null) {
        final List<dynamic> decoded = jsonDecode(cached);
        if (mounted) {
          setState(() {
            _contacts = decoded.map((x) => Map<String, dynamic>.from(x)).toList();
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      print('Error loading cached contacts: $e');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _toggleContactSelection(String uid) {
    setState(() {
      if (_selectedContactIds.contains(uid)) {
        _selectedContactIds.remove(uid);
      } else {
        _selectedContactIds.add(uid);
      }
    });
  }

  Future<void> _forwardMessages() async {
    if (_selectedContactIds.isEmpty) return;
    setState(() => _isForwarding = true);

    try {
      final forwardedMessage = {
        ...widget.message,
        'forwarded': true,
        'originalSender': widget.message['sender'],
        'sender': _auth.currentUser!.uid,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      // Remove fields that shouldn't be forwarded
      forwardedMessage.remove('id');
      forwardedMessage.remove('read');
      forwardedMessage.remove('reaction');
      forwardedMessage.remove('reactedBy');

      // Send to all selected contacts
      await Future.wait(_selectedContactIds.map((contactId) async {
        try {
          await _messageService.sendMessage(
            _auth.currentUser!.uid,
            contactId,
            forwardedMessage,
          );
        } catch (e) {
          print('Error forwarding to $contactId: $e');
          rethrow;
        }
      }));

      if (mounted) {
        Navigator.pop(context, true);
      }
    } catch (e) {
      print('Error in forwarding process: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to forward messages: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isForwarding = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forward Message'),
        actions: [
          if (_selectedContactIds.isNotEmpty)
            TextButton.icon(
              onPressed: _isForwarding ? null : _forwardMessages,
              icon: _isForwarding 
                ? SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Icon(Icons.send, color: Colors.white),
              label: Text(
                'Send to ${_selectedContactIds.length}',
                style: TextStyle(color: Colors.white),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            color: Colors.grey[100],
            child: Row(
              children: [
                Icon(Icons.forward, color: Colors.grey[600]),
                SizedBox(width: 16),
                Expanded(
                  child: Text(
                    widget.message['content'] ?? 'Forwarded message',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: _contacts.length,
                    itemBuilder: (context, index) {
                      final contact = _contacts[index];
                      final isSelected = _selectedContactIds.contains(contact['uid']);

                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: contact['photoUrl'] != null 
                              ? NetworkImage(contact['photoUrl'])
                              : null,
                          child: contact['photoUrl'] == null
                              ? Text((contact['name'] ?? '?')[0].toUpperCase())
                              : null,
                        ),
                        title: Text(contact['name'] ?? 'No name'),
                        subtitle: Text(contact['mobile'] ?? ''),
                        trailing: isSelected
                            ? Icon(Icons.check_circle, color: Theme.of(context).primaryColor)
                            : Icon(Icons.radio_button_unchecked),
                        onTap: () => _toggleContactSelection(contact['uid']),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
